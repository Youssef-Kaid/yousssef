# Omayma's part:

import requests

def lookup_book(title):
    try:

        response= requests.get("https://openlibrary.org/search.json",params={"title":title},
                               timeout=5
                               )
        data = response.json()

        if data.get("docs"):
           
            for doc in data["docs"]:
                if doc.get("author_name") and len(doc["author_name"])> 0 and "first_publish_year" in doc:
                    author= doc["author_name"][0]
                    year= doc ["first_publish_year"]
                    return{"author":author,
                           "year": year
                    }
        print("Could not find book details online.")        
        return None        


    except requests.exceptions.RequestException:
        print("API connection failed. Please check your internet connection.")
        return None