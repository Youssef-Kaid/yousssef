#Yousef part:

from tabulate import tabulate
from library_app.api_lookup import lookup_book

# For each book we record:
# - Title
# - Author
# - Year
# - genre


# --------------------------------------------------
# FUNCTION: ADD A NEW BOOK
# --------------------------------------------------

def add_book(books):

    while True:

        print("\n===== Add a New Book =====")

        title = input("Enter a book title: ").strip()

        # Try to auto-fill author and year using the online lookup
        result = lookup_book(title)

        if result:
            print(f"Found online: {result['author']} ({result['year']})")
            use_online = input("Use this info? (yes/no): ").strip().lower()
        else:
            use_online = "no"

        if result and use_online == "yes":
            author = result["author"]
            year = result["year"]
        else:
            author = input("Enter the author's name: ").strip()

            # to enter the release year: abc. For the program not to crash, and to get asked again.
            while True:
                try:
                    year = int(input("Enter the book's release year: "))

                    if 1800 <= year <= 2027:
                        break

                    print("Please enter a year between 1800 and 2027.")

                except ValueError:
                    print("Please enter a valid number for the year.")

        # --------------------------------------------------
        # Enter genres
        # --------------------------------------------------

        genres = []

        while True:
            try:
                number_of_genres = int(
                    input("How many genres does this book have: ")
                )

                if number_of_genres > 0:
                    break

                else:
                    print("Please enter a number greater than 0.")

            except ValueError:
                print("Something went wrong. Please enter a valid number.")

        while len(genres) < number_of_genres:

            add_genre = input(
                f"Enter genre {len(genres) + 1}: ").strip()

            # Check if the genre already exists
            genre_already_exists = any(
                genre.lower() == add_genre.lower()
                for genre in genres
            )

            if not add_genre:
                print("Genre cannot be empty.")

            elif genre_already_exists:
                print(
                    "This genre has already been added. "
                    "Please enter another genre."
                )

            else:
                genres.append(add_genre)

        # --------------------------------------------------
        # Create the book
        # --------------------------------------------------

        book = {
            "title": title,
            "author": author,
            "year": year,
            "genre": genres
        }

        # Add the book to the books list
        books.append(book)

        print("\nThe book was added successfully!")

        # Ask if the user wants to add another book
        while True:
            choice = input("\nDo you want to add another book? (yes/no): ").strip().lower()

            if choice == "yes":
                break

            elif choice == "no":
                return

            else:
                print("Please enter 'yes' or 'no'.")


# --------------------------------------------------
# FUNCTION: VIEW ALL BOOKS
# --------------------------------------------------
# The assignment specifically wants the books displayed in a readable, aligned format, and it must handle an empty library.

def view_books(books):

    print("\n===== Your Library =====")

    if not books:
        print("The library is empty.")
        return

    # Create rows for the table
    table = []

    for book in books:
        genres = ", ".join(book["genre"])

        table.append([
            book["title"],
            book["author"],
            book["year"],
            genres
        ])
        # Display the books using tabulate

    print(
        tabulate(
            table,
            headers=["Title", "Author", "Year", "Genre"],
            tablefmt="grid"
        )
    )


# --------------------------------------------------
# FUNCTION: SEARCH FOR A BOOK BY TITLE OR AUTHOR
# --------------------------------------------------
# The search code shouldn't be specifically for an author and exact match.
# The assignment requires:
# - searches by title OR author
# - is case-insensitive
# - allows partial matches

def search_books(books):

    while True:

        # Display the search section heading
        print("\n===== Search Books =====")

        # Ask the user what they want to search for
        # .lower() makes the search case-insensitive
        search_term = input(
            "Enter a title or author to search for: "
        ).strip().lower()

        # Start by assuming that no book has been found
        found = False

        # Store matching books for the tabulate table
        search_results = []

        # Go through every book in the books list
        for book in books:

            # Check if the search term is contained in the title
            # OR if it is contained in the author's name
            if (
                search_term in book["title"].lower()
                or search_term in book["author"].lower()
            ):

                # Join all the genres into one readable string
                genres = ", ".join(book["genre"])

                # Add the matching book to the table
                search_results.append([
                    book["title"],
                    book["author"],
                    book["year"],
                    genres
                ])

                # A matching book was found
                found = True

        # Display the search results
        if found:

            print(
                tabulate(
                    search_results,
                    headers=["Title", "Author", "Year", "Genre"],
                    tablefmt="grid"
                )
            )

            # A book was found, so return to the main menu
            return

        # If no matching book was found, ask the user what to do
        else:

            print("No books found.")

            while True:

                choice = input(
                    "Would you like to search again? (yes/no): "
                ).strip().lower()

                if choice == "yes":
                    break

                elif choice == "no":
                    return

                else:
                    print("Please enter 'yes' or 'no'.")


# --------------------------------------------------
# FUNCTION: CONFIRM DELETION
# --------------------------------------------------

def confirm_delete(book_title):

    while True:

        confirm = input(
            f'Are you sure you want to delete "{book_title}"? (yes/no): '
        )

        if confirm.lower() == "yes":
            return True

        elif confirm.lower() == "no":
            return False

        else:
            print("Please enter only yes or no.")


# --------------------------------------------------
# FUNCTION: DELETE A BOOK
# --------------------------------------------------

def delete_book(books):

    print("\n===== Delete a Book =====")

    if not books:
        print("The library is empty.")
        return

    while True:

        # Display the books with numbers
        print("\nBooks in your library:")

        for i, book in enumerate(books, start=1):
            print(f"{i}. {book['title']}")

        # Ask the user for the title
        title_to_delete = input(
            "\nEnter the title of the book you want to delete: "
        )

        # Search for the book
        book_found = False

        for book in books:

            if book["title"].lower() == title_to_delete.lower():

                book_found = True

                # Ask for confirmation
                if confirm_delete(book["title"]):

                    books.remove(book)

                    print(
                        f'"{book["title"]}" was deleted successfully.'
                    )

                else:

                    print("Book was not deleted.")

                break

        if not book_found:
            print("Book not found.")

        # Ask if the user wants to delete another book
        if books:

            while True:

                another = input(
                    "\nDo you still need to delete a book? (yes/no): "
                )

                if another.lower() == "yes":
                    break

                elif another.lower() == "no":
                    print("Returning to the main menu.")
                    return

                else:
                    print("Please enter only yes or no.")

        else:

            print("There are no more books to delete.")
            return
