#Anhar's Part:

import os
import json
import csv


def load_library(filepath):
    if not os.path.exists(filepath):
        return []

    try:
        with open(filepath, "r", encoding="utf-8") as file:
            books = json.load(file)

        return books

    except json.JSONDecodeError:
        print("Error: The library file contains invalid JSON.")
        return []


def save_library(filepath, books):
    with open(filepath, "w", encoding="utf-8") as file:
        json.dump(books, file, indent=4)


def export_to_csv(books, filepath):
    with open(filepath, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(
            file,
            fieldnames=["title", "author", "year", "genre"]
        )

        writer.writeheader()

        for book in books:
            writer.writerow({
                "title": book["title"],
                "author": book["author"],
                "year": book["year"],
                "genre": ", ".join(book["genre"])
            })


def import_from_csv(filepath):
    try:
        with open(filepath, "r", newline="", encoding="utf-8") as file:
            reader = csv.DictReader(file)

            books = []

            for row in reader:
                book = {
                    "title": row["title"],
                    "author": row["author"],
                    "year": int(row["year"]),
                    "genre": [
                        genre.strip()
                        for genre in row["genre"].split(",")
                    ]
                }
                books.append(book)

        return books

    except FileNotFoundError:
        print("Error: The CSV file was not found.")
        return []
