
import os

from library_app.file_handler import load_library, save_library, export_to_csv, import_from_csv
from library_app.book_operations import add_book, view_books, search_books, delete_book

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LIBRARY_PATH = os.path.join(BASE_DIR, "data", "library.json")

def main_menu():
    print("---{Welcome to Al-Razi Library Manager}---")
    print("1. Add a book")
    print("2. View all books")
    print("3. Search books")
    print("4. Delete a book")
    print("5. Export to CSV")
    print("6. Import from CSV")
    print("7. Exit")
    return input("Choose desired option: ")


def main():
    books = load_library(LIBRARY_PATH)

    while True:
        choice = main_menu()
        if choice == "1":
            add_book(books)
            save_library(LIBRARY_PATH, books)
        elif choice == "2":
            view_books(books)
        elif choice == "3":
            search_books(books)
        elif choice == "4":
            delete_book(books)
            save_library(LIBRARY_PATH, books)
        elif choice == "5":
            filename = input("Enter file name to export to (e.g. NameOfChoice.csv): ").strip()
            export_path = os.path.join(BASE_DIR, filename)
            export_to_csv(books, export_path)
        elif choice == "6":
            filename = input("Enter file name to import from (e.g. Test.csv): ").strip()
            csv_path = os.path.join(BASE_DIR, filename)
            imported_books = import_from_csv(csv_path)
            if imported_books:
                books.extend(imported_books)
                save_library(LIBRARY_PATH, books)
                print(f"Imported {len(imported_books)} book(s).")
        elif choice == "7":
            print("Happy to serve, GoodBye")
            break
        else:
            print("Invalid choice or input. Please try again!")

if __name__ == "__main__":
    main()





    
