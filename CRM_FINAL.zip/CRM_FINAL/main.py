"""
=============================================================
NEXUS CRM - Week 5 Capstone (UI only)
=============================================================
Run this file to start the application:

    python main.py

Project structure:

    CRM_App/
    +-- main.py               <- run this file to start the app
    +-- preview_ui.py         <- opens any .ui design in a window
    +-- images/               <- put p_screen.png (wallpaper) here
    +-- ui/                   <- Qt Designer .ui files (one per page)
    +-- py_files/
        +-- pages/            <- ONLY the page files
        |     login_page.py, signup_page.py, preferences_page.py,
        |     applications_page.py, mentor_page.py,
        |     interviews_page.py, admin_page.py
        +-- core/             <- everything else (settings, layouts)
              config.py, styles.py, helpers.py, widgets.py,
              tables.py, base_page.py, main_window.py

Only the interface is built this week: the tables should be empty and
no real database, e-mail or calendar is connected. But we made some 
contents in the tables to test the interface.


=============================================================
"""

import sys

from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import QApplication

from py_files.core.config import SETTINGS_APPLICATION, SETTINGS_ORGANIZATION
from py_files.core.main_window import MainWindow


def main():
    """Start the PyQt6 application."""
    # Step 1: create the application object
    app = QApplication(sys.argv)

    # Step 2: names used by QSettings ("Remember me")
    app.setApplicationName(SETTINGS_APPLICATION)
    app.setOrganizationName(SETTINGS_ORGANIZATION)

    # Step 3: default font
    app.setFont(QFont("Segoe UI", 10))

    # Step 4: create and show the main window
    window = MainWindow()
    window.show()

    # Step 5: run until the window is closed
    sys.exit(app.exec())


# Only run when this file is started directly
if __name__ == "__main__":
    main()
