"""
preview_ui.py
-------------
Opens any Qt Designer .ui file in a window so you can check the design.

Usage (from the CRM_App folder):

    python preview_ui.py ui/login_page.ui
    python preview_ui.py ui/applications_page.ui

If you give no file name, login_page.ui is opened.

(UI prototype - created with AI assistance, see main.py.)
"""

import sys
from pathlib import Path

from PyQt6 import uic
from PyQt6.QtWidgets import QApplication

# Folder that contains this file (so the path works on any computer)
BASE_DIR = Path(__file__).resolve().parent

# Step 1: choose the .ui file (from the command line, or the default)
if len(sys.argv) > 1:
    ui_file = Path(sys.argv[1])
    if not ui_file.is_absolute():
        ui_file = Path.cwd() / ui_file
else:
    ui_file = BASE_DIR / "ui" / "login_page.ui"

# Step 2: create the application
app = QApplication(sys.argv)

# Step 3: load the design from the .ui file
window = uic.loadUi(str(ui_file))

# Step 4: show it at the normal size
window.resize(1280, 860)
window.show()

# Step 5: run until the window is closed
sys.exit(app.exec())
