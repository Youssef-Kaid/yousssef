"""Configuration, styles, layouts, widgets, helpers and the main window."""
