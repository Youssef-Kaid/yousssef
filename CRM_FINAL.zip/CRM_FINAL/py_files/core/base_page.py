"""
base_page.py
------------
BasePage: the parent class of every page (background + main layout).
build_auth_layout: the shared layout used by the Login and Sign-up
pages (brand card on the left, form panel on the right).

(UI prototype - created with AI assistance, see main.py.)
"""

from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import QVBoxLayout, QHBoxLayout, QLabel, QFrame, QSizePolicy

from py_files.core.widgets import BackgroundWidget, PageHeader, ActionButton
from py_files.core.helpers import small_label_style


class BasePage(BackgroundWidget):
    """Base class shared by every application page."""

    def __init__(self, accent, parent=None):
        super().__init__(parent)

        # Each page has its own accent colour
        self.accent = accent

        # Main vertical layout that holds everything on the page
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(42, 28, 42, 28)
        self.main_layout.setSpacing(18)

    def add_top_brand(self):
        """Add the small 'NEXUS / CRM' line at the top."""
        brand_layout = QHBoxLayout()
        brand = QLabel("NEXUS  /  CRM")
        brand.setStyleSheet(small_label_style(self.accent, 11, 800, "1.5px"))
        brand_layout.addWidget(brand)
        brand_layout.addStretch()
        self.main_layout.addLayout(brand_layout)

    def add_header(self, eyebrow, title, subtitle):
        """Add the big page header box."""
        header = PageHeader(eyebrow, title, subtitle, self.accent)
        self.main_layout.addWidget(header)
        return header


# ============================================================
# SHARED LAYOUT FOR LOGIN AND SIGN-UP
# ============================================================

AUTH_PANEL_WIDTH = 500      # Width of the right-hand form panel
BRAND_CARD_SIZE = (560, 480)  # Width and height of the left card

# Look of the right-hand form panel
AUTH_PANEL_STYLE = """
QFrame#authPanel {
    background: rgb(22, 34, 53);
    border: 1px solid rgba(100, 116, 139, 110);
    border-radius: 24px;
}
"""


def build_auth_layout(page, panel, accent, title_text, description, points):
    """
    Put a readable brand card on the left and the form panel on the right.
    Both pages use this function, so the cards and panels are identical
    in size and structure.
    """

    # Row that holds [left card | right panel]
    outer = QHBoxLayout()
    outer.setContentsMargins(20, 8, 20, 8)
    outer.setSpacing(48)

    # Left column: card centred vertically
    left = QVBoxLayout()
    left.addStretch()

    # ---- Brand card ----
    card = QFrame()
    card.setObjectName("brandCard")
    card.setFixedSize(*BRAND_CARD_SIZE)       # Same size on both pages
    card.setStyleSheet(
        f"""
        QFrame#brandCard {{
            background: rgba(8, 13, 24, 210);
            border: 1px solid rgba(148, 163, 184, 70);
            border-left: 4px solid {accent};
            border-radius: 22px;
        }}
        """
    )

    card_layout = QVBoxLayout(card)
    card_layout.setContentsMargins(44, 40, 44, 40)
    card_layout.setSpacing(12)

    # Small "NEXUS" label in a lighter shade of the accent
    eyebrow = QLabel("NEXUS")
    eyebrow.setStyleSheet(
        small_label_style(ActionButton.lighten_color(accent, 45), 15, 800, "4px")
    )

    # Large title. The font is set in code (not in the stylesheet)
    # and the minimum height is set explicitly so no line is clipped.
    title = QLabel(title_text)
    title_font = QFont()
    title_font.setPixelSize(42)
    title_font.setWeight(QFont.Weight.ExtraBold)
    title.setFont(title_font)
    title.setWordWrap(False)                       # Lines break only at "\n"
    title_lines = title_text.count("\n") + 1
    title.setMinimumHeight(int(title_lines * 42 * 1.4) + 12)
    title.setStyleSheet(
        "QLabel { color: #FFFFFF; background: transparent; border: none; }"
    )

    # Description paragraph
    desc = QLabel(description)
    desc.setWordWrap(True)
    desc.setStyleSheet(small_label_style("#E2E8F0", 15, 400))

    card_layout.addWidget(eyebrow)
    card_layout.addWidget(title)
    card_layout.addWidget(desc)
    card_layout.addSpacing(14)

    # Checklist lines - wrapping is off so each stays on ONE line
    for point in points:
        row = QLabel(f"\u2713   {point}")
        row.setWordWrap(False)
        row.setStyleSheet(small_label_style("#F1F5F9", 13, 600))
        card_layout.addWidget(row)

    # Push everything to the top of the card
    card_layout.addStretch()

    left.addWidget(card, 0, Qt.AlignmentFlag.AlignLeft)
    left.addStretch()

    # ---- Right-hand form panel ----
    panel.setObjectName("authPanel")
    panel.setStyleSheet(AUTH_PANEL_STYLE)
    panel.setFixedWidth(AUTH_PANEL_WIDTH)
    panel.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)

    # Add both sides to the row, then the row to the page
    outer.addLayout(left, 1)
    outer.addWidget(panel)
    page.main_layout.addLayout(outer, 1)
