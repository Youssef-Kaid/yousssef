"""
config.py
---------
Shared constants for the NEXUS CRM interface:
window size, file locations, and the colour theme.

(UI prototype - created with AI assistance, see main.py.)
"""

from pathlib import Path

# ------------------------------------------------------------
# Application settings
# ------------------------------------------------------------

APP_TITLE = "NEXUS CRM"          # Text shown in the window title bar
WINDOW_WIDTH = 1280              # Default window width in pixels
WINDOW_HEIGHT = 860              # Default window height in pixels
MIN_WIDTH = 1240                 # Smallest allowed width (fits the left card)
MIN_HEIGHT = 760                 # Smallest allowed height

# Project root folder (CRM_App). config.py sits in CRM_App/py_files/core,
# so the root is three levels up. Used to find images/ and users.json.
BASE_DIR = Path(__file__).resolve().parent.parent.parent

# Folder with the Qt Designer .ui files
UI_DIR = BASE_DIR / "ui"

# Local file where demo accounts created on the Sign-up page are stored
USERS_FILE = BASE_DIR / "users.json"

# Used by QSettings to remember the "Remember me" username
SETTINGS_ORGANIZATION = "NexusCRM"
SETTINGS_APPLICATION = "Week5Capstone"

# Places where the background picture (p_screen.png) may be stored
BACKGROUND_CANDIDATES = [
    BASE_DIR / "images" / "p_screen.png",
    BASE_DIR / "Preferences" / "images" / "p_screen.png",
    BASE_DIR / "Main_Menu" / "Preferences" / "images" / "p_screen.png",
]

# ------------------------------------------------------------
# Colour theme
# ------------------------------------------------------------

NAVY = "#0B1120"          # Main dark background
NAVY_2 = "#111827"        # Slightly lighter dark
PANEL = "#172033"         # Panels
PANEL_2 = "#1D293D"       # Secondary panels

TEXT = "#F8FAFC"          # Main text (almost white)
TEXT_SOFT = "#D7E0EC"     # Softer text
MUTED = "#8FA1B7"         # Muted grey-blue text
MUTED_2 = "#71839A"       # Even more muted text

BORDER = "#334155"        # Default border colour
BORDER_SOFT = "#26364D"   # Softer border colour

WHITE = "#FFFFFF"

# One accent colour per page
ACCENTS = {
    "login": "#8B5CF6",
    "signup": "#A855F7",
    "preferences": "#06B6D4",
    "applications": "#3B82F6",
    "mentor": "#F59E0B",
    "interviews": "#10B981",
    "admin": "#EC4899",
}
