"""
helpers.py
----------
Small helper functions that do NOT draw anything:
password hashing, reading/writing users.json, saved settings,
and a label-style builder.

(UI prototype - created with AI assistance, see main.py.)
"""

import hashlib
import hmac
import json
import secrets

from PyQt6.QtCore import QSettings

from py_files.core.config import (
    USERS_FILE,
    SETTINGS_ORGANIZATION,
    SETTINGS_APPLICATION,
    BACKGROUND_CANDIDATES,
)


def find_background():
    """Return the first existing background image path, or None."""
    # Check each possible location in order
    for path in BACKGROUND_CANDIDATES:
        if path.exists():
            return path
    # No image found: the app falls back to a gradient
    return None


def hash_password(password: str, salt: bytes | None = None):
    """Hash a password with PBKDF2-HMAC-SHA256. Returns (salt_hex, hash_hex)."""
    # Create a random salt if one was not supplied
    if salt is None:
        salt = secrets.token_bytes(16)

    # Run the hashing algorithm 120,000 times (makes guessing slower)
    password_hash = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt, 120_000
    )

    # Return both values as text so they can be saved in JSON
    return salt.hex(), password_hash.hex()


def verify_password(password: str, salt_hex: str, stored_hash: str):
    """Check a typed password against a stored salt + hash."""
    # Convert the saved salt back to bytes
    try:
        salt = bytes.fromhex(salt_hex)
    except (ValueError, TypeError):
        return False

    # Hash the typed password with the same salt
    _, calculated_hash = hash_password(password, salt)

    # Compare in a timing-safe way
    return hmac.compare_digest(calculated_hash, stored_hash)


def load_users():
    """Read users.json. Returns an empty dict if missing or broken."""
    # No file yet means no accounts
    if not USERS_FILE.exists():
        return {}

    try:
        with open(USERS_FILE, "r", encoding="utf-8") as file:
            data = json.load(file)
        # Only accept a dictionary
        return data if isinstance(data, dict) else {}
    except (json.JSONDecodeError, OSError, TypeError):
        return {}


def save_users(users):
    """Write the users dictionary to users.json. Returns True on success."""
    try:
        with open(USERS_FILE, "w", encoding="utf-8") as file:
            json.dump(users, file, indent=4)
        return True
    except OSError:
        return False


def get_app_settings():
    """Return the QSettings object (stores the 'Remember me' username)."""
    return QSettings(SETTINGS_ORGANIZATION, SETTINGS_APPLICATION)


def small_label_style(color, size=10, weight=700, spacing=None):
    """Build a stylesheet string for a transparent, borderless label."""
    # Optional letter spacing line
    extra = f"letter-spacing: {spacing};" if spacing else ""
    return f"""
        QLabel {{
            color: {color};
            font-size: {size}px;
            font-weight: {weight};
            {extra}
            background: transparent;
            border: none;
        }}
    """
