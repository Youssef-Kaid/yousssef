"""
main_window.py
--------------
MainWindow: creates every page, puts them in one stacked widget
and provides the show_...() functions used for navigation.

(UI prototype - created with AI assistance, see main.py.)
"""

from PyQt6.QtWidgets import QMainWindow, QStackedWidget

from py_files.core.config import APP_TITLE, WINDOW_WIDTH, WINDOW_HEIGHT, MIN_WIDTH, MIN_HEIGHT
from py_files.core.styles import GLOBAL_STYLE
from py_files.pages.login_page import LoginPage
from py_files.pages.signup_page import SignupPage
from py_files.pages.preferences_page import PreferencesPage
from py_files.pages.applications_page import ApplicationsPage
from py_files.pages.mentor_page import MentorInterviewPage
from py_files.pages.interviews_page import InterviewsPage
from py_files.pages.admin_page import AdminPage


class MainWindow(QMainWindow):
    """The one window of the application. Pages are swapped inside it."""

    def __init__(self):
        super().__init__()

        # Remember who is logged in
        self.current_username = ""
        self.current_is_admin = False

        # Window title, size and global style
        self.setWindowTitle(APP_TITLE)
        self.resize(WINDOW_WIDTH, WINDOW_HEIGHT)
        self.setMinimumSize(MIN_WIDTH, MIN_HEIGHT)
        self.setStyleSheet(GLOBAL_STYLE)

        # The stacked widget shows ONE page at a time
        self.stack = QStackedWidget()
        self.setCentralWidget(self.stack)

        # Step 1: create the pages (user and admin versions where needed)
        self.login_page = LoginPage()
        self.signup_page = SignupPage()

        self.preferences_page = PreferencesPage(is_admin=False)
        self.admin_preferences_page = PreferencesPage(is_admin=True)

        self.applications_page = ApplicationsPage(is_admin=False)
        self.admin_applications_page = ApplicationsPage(is_admin=True)

        self.mentor_page = MentorInterviewPage(is_admin=False)
        self.admin_mentor_page = MentorInterviewPage(is_admin=True)

        self.interviews_page = InterviewsPage(is_admin=False)
        self.admin_interviews_page = InterviewsPage(is_admin=True)

        self.admin_page = AdminPage()

        # Step 2: add every page to the stack
        for page in (
            self.login_page, self.signup_page,
            self.preferences_page, self.admin_preferences_page,
            self.applications_page, self.admin_applications_page,
            self.mentor_page, self.admin_mentor_page,
            self.interviews_page, self.admin_interviews_page,
            self.admin_page,
        ):
            self.stack.addWidget(page)

        # Step 3: connect the signals sent by the login / signup pages
        self.login_page.login_success.connect(self.handle_login_success)
        self.login_page.signup_requested.connect(self.show_signup)
        self.login_page.close_requested.connect(self.close)
        self.signup_page.back_requested.connect(self.show_login)

        # Step 4: start on the Sign-in page
        self.show_login()

    # ========================================================
    # Navigation functions (called by the pages)
    # ========================================================

    def show_login(self):
        """Show the Sign-in page and log the user out."""
        self.current_username = ""
        self.current_is_admin = False
        self.stack.setCurrentWidget(self.login_page)
        self.login_page.clear_form()

    def show_signup(self):
        """Show the Create account page."""
        self.signup_page.clear_form()
        self.stack.setCurrentWidget(self.signup_page)

    def handle_login_success(self, username, is_admin):
        """Called after a successful login."""
        self.current_username = username
        self.current_is_admin = is_admin

        # Update the welcome banner on the admin Preferences page
        if is_admin:
            self.admin_preferences_page.set_user(username)

        self.show_preferences(is_admin)

    def show_preferences(self, is_admin=False):
        """Show the admin or standard Preferences page."""
        page = self.admin_preferences_page if is_admin else self.preferences_page
        self.stack.setCurrentWidget(page)

    def show_applications(self, is_admin=False):
        """Show the Applications page."""
        page = self.admin_applications_page if is_admin else self.applications_page
        self.stack.setCurrentWidget(page)

    def show_mentor(self, is_admin=False):
        """Show the Mentor Interview page."""
        page = self.admin_mentor_page if is_admin else self.mentor_page
        self.stack.setCurrentWidget(page)

    def show_interviews(self, is_admin=False):
        """Show the Interviews page."""
        page = self.admin_interviews_page if is_admin else self.interviews_page
        self.stack.setCurrentWidget(page)

    def show_admin(self):
        """Show the Admin menu (administrators only)."""
        # Standard users are sent back to their Preferences page
        if not self.current_is_admin:
            self.show_preferences(False)
            return
        self.stack.setCurrentWidget(self.admin_page)
