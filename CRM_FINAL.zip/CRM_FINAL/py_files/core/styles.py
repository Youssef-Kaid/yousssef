"""
styles.py
---------
The global Qt stylesheet applied to the whole window.
It styles text boxes, drop-downs, check boxes, lists and scroll bars.

(UI prototype - created with AI assistance, see main.py.)
"""

from py_files.core.config import NAVY, TEXT, TEXT_SOFT, MUTED

GLOBAL_STYLE = f"""
/* Window background */
QMainWindow {{ background: {NAVY}; }}

/* Default font and text colour for every widget */
QWidget {{
    font-family: "Segoe UI", Arial, sans-serif;
    color: {TEXT};
}}

/* Single-line text boxes */
QLineEdit {{
    background: rgba(9, 17, 31, 185);
    border: 1px solid rgba(100, 116, 139, 110);
    border-radius: 10px;
    padding: 12px 14px;
    color: {TEXT};
    selection-background-color: rgba(59, 130, 246, 150);
}}
QLineEdit:hover {{ border: 1px solid rgba(148, 163, 184, 170); }}
QLineEdit:focus {{
    border: 1px solid rgba(96, 165, 250, 220);
    background: rgba(9, 17, 31, 215);
}}

/* Drop-down boxes */
QComboBox {{
    background: rgba(9, 17, 31, 180);
    border: 1px solid rgba(100, 116, 139, 120);
    border-radius: 10px;
    padding: 10px 12px;
    color: {TEXT};
}}
QComboBox:hover {{ border: 1px solid rgba(148, 163, 184, 180); }}
QComboBox::drop-down {{ border: none; width: 28px; }}

/* The list that opens under a drop-down */
QComboBox QAbstractItemView {{
    background: #111827;
    color: {TEXT};
    border: 1px solid #334155;
    selection-background-color: #263F62;
    padding: 4px;
    outline: 0;
}}
QComboBox QAbstractItemView::item {{
    min-height: 30px;
    padding: 4px 10px;
}}

/* Check boxes */
QCheckBox {{ color: {MUTED}; spacing: 8px; }}
QCheckBox:hover {{ color: {TEXT_SOFT}; }}

/* Multi-line text boxes */
QTextEdit {{
    background: rgba(9, 17, 31, 180);
    border: 1px solid rgba(100, 116, 139, 120);
    border-radius: 10px;
    padding: 10px;
    color: {TEXT};
}}

/* Lists */
QListWidget {{
    background: rgba(9, 17, 31, 150);
    border: 1px solid rgba(100, 116, 139, 100);
    border-radius: 12px;
}}
QListWidget::item {{ padding: 10px; border-radius: 8px; }}
QListWidget::item:selected {{ background: rgba(59, 130, 246, 90); }}

/* Vertical scroll bars */
QScrollBar:vertical {{ background: transparent; width: 8px; }}
QScrollBar::handle:vertical {{
    background: rgba(148, 163, 184, 90);
    border-radius: 4px;
}}
QScrollBar::handle:vertical:hover {{ background: rgba(148, 163, 184, 150); }}
"""
