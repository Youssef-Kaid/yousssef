"""
tables.py
---------
Table helpers used by the Applications, Mentor Interview,
Interviews and Admin pages.

The tables are created EMPTY (headers only) because this week's
assignment is the interface only, not the table content.

(UI prototype - created with AI assistance, see main.py.)
"""

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QTableWidget, QTableWidgetItem, QAbstractItemView, QScrollBar,
)


class ScrollTable(QTableWidget):
    """
    A table with a slim floating scroll bar.

    The normal scroll bar is hidden and replaced by an overlay bar that
    starts BELOW the header row. The header therefore stays full width
    (so its corners can be rounded) and the bar never cuts into it.
    """

    # Look of the floating scroll bar
    BAR_STYLE = """
        QScrollBar:vertical { background: transparent; width: 10px; margin: 0px; }
        QScrollBar::handle:vertical {
            background: rgba(148, 163, 184, 110);
            border-radius: 4px;
            min-height: 30px;
            margin: 0px 1px;
        }
        QScrollBar::handle:vertical:hover { background: rgba(148, 163, 184, 180); }
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
        QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
            background: transparent;
        }
    """

    def __init__(self, parent=None):
        super().__init__(parent)

        # Step 1: hide the built-in vertical scroll bar
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        # Step 2: create our own scroll bar as a child of the table
        self._bar = QScrollBar(Qt.Orientation.Vertical, self)
        self._bar.setStyleSheet(self.BAR_STYLE)
        self._bar.hide()   # Only shown when there is something to scroll

        # Step 3: keep both scroll bars in sync
        native = self.verticalScrollBar()
        native.rangeChanged.connect(self._sync_range)
        native.valueChanged.connect(self._bar.setValue)
        self._bar.valueChanged.connect(native.setValue)

    def _sync_range(self, minimum, maximum):
        """Copy the scroll range and show the bar only when needed."""
        self._bar.setRange(minimum, maximum)
        self._bar.setPageStep(self.verticalScrollBar().pageStep())
        self._bar.setVisible(maximum > minimum)
        self._place_bar()

    def _place_bar(self):
        """Position the bar on the right edge, under the header."""
        top = self.horizontalHeader().height() + 8
        height = max(0, self.height() - top - 14)
        self._bar.setGeometry(self.width() - 14, top, 10, height)
        self._bar.setPageStep(self.verticalScrollBar().pageStep())
        self._bar.raise_()

    def resizeEvent(self, event):
        # Re-position the bar whenever the table changes size
        super().resizeEvent(event)
        self._place_bar()


def style_table(table, accent):
    """Apply the shared dark table look (rounded header, hover, selection)."""
    # Basic behaviour
    table.setAlternatingRowColors(False)
    table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
    table.setShowGrid(False)
    table.setSortingEnabled(True)
    table.setMouseTracking(True)

    # Cells cannot be edited by double-clicking
    table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)

    # Solid background avoids "ghost" text when rows change
    table.viewport().setAutoFillBackground(True)

    # Colours, borders and rounded header corners
    table.setStyleSheet(
        f"""
        QTableWidget {{
            background: #0E1727;
            alternate-background-color: transparent;
            color: #E2E8F0;
            border: 1px solid rgba(100, 116, 139, 110);
            border-radius: 15px;
            gridline-color: rgba(71, 85, 105, 50);
            selection-background-color: transparent;
            selection-color: #FFFFFF;
            outline: none;
        }}
        QTableWidget::item {{
            background: transparent;
            border-bottom: 1px solid rgba(71, 85, 105, 35);
            padding: 8px;
        }}
        QTableWidget::item:hover {{ background: rgba(59, 130, 246, 38); }}
        QTableWidget::item:selected {{
            background: qlineargradient(
                x1: 0, y1: 0, x2: 1, y2: 0,
                stop: 0 rgba(59, 130, 246, 100),
                stop: 0.50 rgba(34, 197, 94, 65),
                stop: 1 rgba(6, 182, 212, 80)
            );
            color: #FFFFFF;
            border-bottom: 1px solid rgba(96, 165, 250, 100);
        }}
        QHeaderView {{ background: transparent; }}
        QHeaderView::section {{
            background: rgba(20, 31, 49, 225);
            color: #DDE7F2;
            border: none;
            border-right: 1px solid rgba(100, 116, 139, 70);
            border-bottom: 1px solid {accent};
            padding: 11px 9px;
            font-size: 10px;
            font-weight: 700;
        }}
        QHeaderView::section:hover {{ background: rgba(32, 47, 70, 235); }}
        QHeaderView::section:first {{ border-top-left-radius: 14px; }}
        QHeaderView::section:last {{
            border-right: none;
            border-top-right-radius: 14px;
        }}
        QTableCornerButton::section {{
            background: rgba(20, 31, 49, 225);
            border: none;
            border-bottom: 1px solid {accent};
        }}
        """
    )

    # Header row settings
    header = table.horizontalHeader()
    header.setDefaultAlignment(
        Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
    )
    header.setStretchLastSection(True)
    header.setMinimumHeight(44)

    # Hide the row numbers on the left and set the row height
    table.verticalHeader().setVisible(False)
    table.verticalHeader().setDefaultSectionSize(44)


def populate_table(table, rows):
    """
    Fill a table with a list of rows.
    (Not used yet - the tables stay empty for this UI-only week.
    It is ready for when real data is added.)
    """
    # Turn sorting off while inserting so rows do not jump around
    table.setSortingEnabled(False)
    table.setRowCount(0)

    # Add every row and every cell
    for row_data in rows:
        row = table.rowCount()
        table.insertRow(row)
        for column, value in enumerate(row_data):
            item = QTableWidgetItem(str(value))
            item.setTextAlignment(
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter
            )
            table.setItem(row, column, item)

    # Turn sorting back on
    table.setSortingEnabled(True)
