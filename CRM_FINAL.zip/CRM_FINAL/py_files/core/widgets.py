"""
widgets.py
----------
Reusable visual building blocks used on every page:
background, glass panels, page header, buttons, info cards,
the welcome banner and the animated message label.

(UI prototype - created with AI assistance, see main.py.)
"""

from PyQt6.QtCore import (
    Qt, QTimer, QPropertyAnimation, QEasingCurve, QRect, QRectF, QDate,
)
from PyQt6.QtGui import (
    QColor, QFont, QPainter, QPen, QBrush, QLinearGradient, QPixmap,
    QFontMetrics,
)
from PyQt6.QtWidgets import (
    QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout, QFrame,
    QGraphicsOpacityEffect, QSizePolicy,
)

from py_files.core.config import (
    NAVY, TEXT, TEXT_SOFT, MUTED, WHITE, BORDER,
)
from py_files.core.helpers import find_background, small_label_style


# ============================================================
# BACKGROUND
# ============================================================

class BackgroundWidget(QWidget):
    """A widget that paints the background picture plus a dark overlay."""

    def __init__(self, parent=None):
        super().__init__(parent)

        # Look for the background image on disk
        self.background_path = find_background()
        self.background_pixmap = None

        # Load it if it exists
        if self.background_path:
            self.background_pixmap = QPixmap(str(self.background_path))

        # Allow the widget to paint its own background
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)

    def paintEvent(self, event):
        # Create a painter that draws on this widget
        painter = QPainter(self)

        if self.background_pixmap and not self.background_pixmap.isNull():
            # Scale the picture so it covers the whole widget
            scaled = self.background_pixmap.scaled(
                self.size(),
                Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                Qt.TransformationMode.SmoothTransformation,
            )

            # Centre the scaled picture
            x = (self.width() - scaled.width()) // 2
            y = (self.height() - scaled.height()) // 2
            painter.drawPixmap(x, y, scaled)

            # Add a dark see-through layer so text is readable
            painter.fillRect(self.rect(), QColor(5, 12, 24, 145))
        else:
            # No picture: fill with the dark colour
            painter.fillRect(self.rect(), QColor(NAVY))

            # Draw a soft diagonal gradient on top
            gradient = QLinearGradient(0, 0, self.width(), self.height())
            gradient.setColorAt(0.0, QColor("#101A2D"))
            gradient.setColorAt(0.5, QColor("#0B1220"))
            gradient.setColorAt(1.0, QColor("#111827"))
            painter.fillRect(self.rect(), QBrush(gradient))

        painter.end()


# ============================================================
# GLASS FRAME
# ============================================================

class GlassFrame(QFrame):
    """A dark, slightly see-through rounded panel."""

    def __init__(self, accent=None, radius=18, opacity=125, parent=None):
        super().__init__(parent)

        # Remember the settings
        self.accent = accent or BORDER
        self.radius = radius
        self.opacity = opacity

        # The object name lets the stylesheet target only this frame
        self.setObjectName("glassFrame")

        # Dark background, coloured border, rounded corners
        self.setStyleSheet(
            f"""
            QFrame#glassFrame {{
                background: rgba(17, 24, 39, {opacity});
                border: 1px solid {self.accent};
                border-radius: {radius}px;
            }}
            """
        )


# ============================================================
# PAGE HEADER
# ============================================================

class PageHeader(QFrame):
    """The big title box at the top of each page."""

    def __init__(self, eyebrow, title, subtitle, accent, parent=None):
        super().__init__(parent)

        # Style the box: dark background, coloured left edge, rounded corners
        self.setObjectName("pageHeader")
        self.setStyleSheet(
            f"""
            QFrame#pageHeader {{
                background: rgba(12, 20, 34, 175);
                border: 1px solid rgba(71, 85, 105, 150);
                border-left: 4px solid {accent};
                border-radius: 18px;
            }}
            """
        )

        # Vertical layout for the three text lines
        layout = QVBoxLayout(self)
        layout.setContentsMargins(26, 22, 26, 22)
        layout.setSpacing(6)

        # Small coloured line above the title
        eyebrow_label = QLabel(eyebrow.upper())
        eyebrow_label.setStyleSheet(small_label_style(accent, 11, 700, "1.5px"))

        # Large page title
        title_label = QLabel(title)
        title_label.setStyleSheet(small_label_style("#F8FAFC", 28, 700))

        # Grey description under the title
        subtitle_label = QLabel(subtitle)
        subtitle_label.setWordWrap(True)
        subtitle_label.setStyleSheet(small_label_style(MUTED, 12, 400))

        # Put the three labels in the layout
        layout.addWidget(eyebrow_label)
        layout.addWidget(title_label)
        layout.addWidget(subtitle_label)


# ============================================================
# ACTION BUTTON
# ============================================================

class ActionButton(QPushButton):
    """The standard rounded button (primary = filled, otherwise outlined)."""

    def __init__(self, text, accent, primary=False, parent=None):
        super().__init__(text, parent)

        self.accent = accent
        self.primary = primary

        # Hand cursor and a comfortable height
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(44)

        # Apply the colours
        self.apply_style()

    def apply_style(self):
        """Choose colours for normal / hover / pressed and set the stylesheet."""
        if self.primary:
            # Filled button using the accent colour
            normal_background = self.accent
            hover_background = self.lighten_color(self.accent, 18)
            pressed_background = self.darken_color(self.accent, 18)
            text_color = WHITE
        else:
            # Dark outlined button
            normal_background = "rgba(17, 27, 44, 185)"
            hover_background = "rgba(38, 58, 84, 225)"
            pressed_background = "rgba(8, 15, 27, 240)"
            text_color = TEXT_SOFT

        # Border colour when the mouse is over the button
        hover_border = self.lighten_color(self.accent, 15)

        self.setStyleSheet(
            f"""
            QPushButton {{
                background: {normal_background};
                color: {text_color};
                border: 1px solid {self.accent};
                border-radius: 11px;
                padding: 10px 18px;
                font-size: 12px;
                font-weight: 700;
            }}
            QPushButton:hover {{
                background: {hover_background};
                border: 1px solid {hover_border};
            }}
            QPushButton:pressed {{
                background: {pressed_background};
                border: 2px solid {self.accent};
                padding-top: 12px;
                padding-left: 19px;
            }}
            QPushButton:disabled {{
                background: rgba(17, 24, 39, 70);
                color: rgba(148, 163, 184, 100);
                border: 1px solid rgba(71, 85, 105, 70);
            }}
            """
        )

    @staticmethod
    def lighten_color(hex_color, amount=15):
        """Return a lighter version of a hex colour."""
        color = QColor(hex_color)
        return QColor(
            min(255, color.red() + amount),
            min(255, color.green() + amount),
            min(255, color.blue() + amount),
        ).name()

    @staticmethod
    def darken_color(hex_color, amount=15):
        """Return a darker version of a hex colour."""
        color = QColor(hex_color)
        return QColor(
            max(0, color.red() - amount),
            max(0, color.green() - amount),
            max(0, color.blue() - amount),
        ).name()


# ============================================================
# NAVIGATION BUTTON
# ============================================================

NAV_BUTTON_HEIGHT = 92   # Every nav button and info card uses this height


class NavButton(QPushButton):
    """
    Large painted button with a title, description and arrow.
    Fixed height + vertically centred text = text can never overlap.
    """

    def __init__(self, title, description, accent, parent=None):
        super().__init__(parent)

        self.title = title
        self.description = description
        self.accent = QColor(accent)

        # Fixed height, stretches sideways
        self.setFixedHeight(NAV_BUTTON_HEIGHT)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMouseTracking(True)

        # We paint everything ourselves, so hide the default look
        self.setStyleSheet(
            "QPushButton { border: none; background: transparent; }"
        )

    def _accent_alpha(self, alpha):
        """Accent colour with a custom transparency."""
        return QColor(
            self.accent.red(), self.accent.green(), self.accent.blue(), alpha
        )

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        # Drawing area (1px inside the edges)
        rect = self.rect().adjusted(1, 1, -1, -1)

        # Pick colours for pressed / hover / normal states
        if self.isDown():
            background = QColor(14, 24, 40, 245)
            border_color = self.accent
        elif self.underMouse():
            background = QColor(38, 56, 82, 245)
            border_color = self._accent_alpha(230)
        else:
            background = QColor(24, 36, 56, 240)
            border_color = self._accent_alpha(160)

        # Draw the rounded button body
        painter.setBrush(QBrush(background))
        painter.setPen(QPen(border_color, 1.2))
        painter.drawRoundedRect(rect, 15, 15)

        # Draw the small coloured bar on the left
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QBrush(self._accent_alpha(220)))
        painter.drawRoundedRect(
            QRect(rect.left(), rect.top() + 14, 4, rect.height() - 28), 2, 2
        )

        # Fonts and their heights, used to centre the text block
        title_font = QFont("Segoe UI", 15, QFont.Weight.Bold)
        description_font = QFont("Segoe UI", 10, QFont.Weight.Normal)
        title_height = QFontMetrics(title_font).height()
        description_height = QFontMetrics(description_font).height()
        gap = 6

        # Vertical start so the whole text block is centred
        block_height = title_height + gap + description_height
        top = rect.top() + (rect.height() - block_height) // 2
        text_width = rect.width() - 24 - 55

        # Draw the title
        painter.setPen(QColor(TEXT))
        painter.setFont(title_font)
        painter.drawText(
            QRect(rect.left() + 24, top, text_width, title_height),
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
            self.title.upper(),
        )

        # Draw the description under it
        painter.setPen(QColor(TEXT_SOFT))
        painter.setFont(description_font)
        painter.drawText(
            QRect(rect.left() + 24, top + title_height + gap,
                  text_width, description_height),
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
            self.description,
        )

        # Draw the arrow on the right
        painter.setPen(self._accent_alpha(230))
        painter.setFont(QFont("Segoe UI", 21, QFont.Weight.Normal))
        painter.drawText(
            rect.adjusted(0, 0, -17, 0),
            Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
            "›",
        )

        painter.end()


# ============================================================
# STATUS CARD
# ============================================================

class StatusCard(QFrame):
    """Solid, non-clickable info card, same height as NavButton."""

    def __init__(self, title, description, accent, parent=None):
        super().__init__(parent)

        # Same height as the navigation buttons so rows line up
        self.setObjectName("statusCard")
        self.setFixedHeight(NAV_BUTTON_HEIGHT)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

        # Solid (not transparent) background with a coloured edge
        self.setStyleSheet(
            f"""
            QFrame#statusCard {{
                background: #1B2A42;
                border: 1px solid {accent};
                border-left: 4px solid {accent};
                border-radius: 15px;
            }}
            """
        )

        # Centre the two text lines vertically
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 0, 24, 0)
        layout.setSpacing(4)
        layout.addStretch()

        # Coloured title
        title_label = QLabel(title.upper())
        title_label.setStyleSheet(small_label_style(accent, 14, 800, "1px"))

        # Light description
        description_label = QLabel(description)
        description_label.setWordWrap(True)
        description_label.setStyleSheet(small_label_style(TEXT_SOFT, 11, 400))

        layout.addWidget(title_label)
        layout.addWidget(description_label)
        layout.addStretch()


# ============================================================
# WELCOME BANNER (admin Preferences page)
# ============================================================

class PillLabel(QLabel):
    """A fully rounded badge, painted with smooth (antialiased) edges."""

    def __init__(self, text, accent, parent=None):
        super().__init__(text, parent)

        self._accent = QColor(accent)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Text colour and padding only; the shape is painted below
        light = ActionButton.lighten_color(accent, 60)
        self.setStyleSheet(
            f"""
            QLabel {{
                color: {light};
                background: transparent;
                border: none;
                padding: 8px 20px;
                font-size: 12px;
                font-weight: 700;
            }}
            """
        )

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        # Pill shape: radius = half of the height
        rect = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        radius = rect.height() / 2

        # Soft fill using the accent colour
        fill = QColor(self._accent)
        fill.setAlpha(45)

        painter.setBrush(QBrush(fill))
        painter.setPen(QPen(self._accent, 1.2))
        painter.drawRoundedRect(rect, radius, radius)
        painter.end()

        # Let QLabel draw the text on top
        super().paintEvent(event)


class WelcomeBanner(QFrame):
    """Greeting banner with the date and a role badge (no CRM data)."""

    def __init__(self, accent, role_text, parent=None):
        super().__init__(parent)

        self._accent = QColor(accent)

        # Fixed height, stretches sideways
        self.setFixedHeight(120)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

        # Text on the left, badge on the right
        layout = QHBoxLayout(self)
        layout.setContentsMargins(30, 16, 30, 16)
        layout.setSpacing(16)

        text_column = QVBoxLayout()
        text_column.setSpacing(4)
        text_column.addStretch()

        light = ActionButton.lighten_color(accent, 60)

        # Today's date (filled in by set_user)
        self.date_label = QLabel()
        self.date_label.setStyleSheet(small_label_style(light, 12, 700))

        # Greeting
        self.title_label = QLabel("Welcome back")
        self.title_label.setContentsMargins(0, 0, 0, 4)
        self.title_label.setStyleSheet(small_label_style("#FFFFFF", 26, 800))

        # Friendly line
        self.message_label = QLabel(
            "Good to see you. Pick an area above whenever you're ready."
        )
        self.message_label.setStyleSheet(small_label_style(TEXT_SOFT, 14, 400))

        text_column.addWidget(self.date_label)
        text_column.addWidget(self.title_label)
        text_column.addWidget(self.message_label)
        text_column.addStretch()

        # Role badge on the right
        badge = PillLabel(role_text, accent)

        layout.addLayout(text_column, 1)
        layout.addWidget(badge, 0, Qt.AlignmentFlag.AlignVCenter)

        # Fill in the default greeting and date
        self.set_user("")

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        # Rounded dark card with an accent border
        rect = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        painter.setBrush(QBrush(QColor("#16233A")))
        painter.setPen(QPen(self._accent, 1.2))
        painter.drawRoundedRect(rect, 26, 26)
        painter.end()

    def set_user(self, name):
        """Update the greeting text and today's date."""
        display = name.strip().capitalize() if name else ""
        self.title_label.setText(
            f"Welcome back, {display}" if display else "Welcome back"
        )
        self.date_label.setText(QDate.currentDate().toString("dddd, d MMMM yyyy"))


# ============================================================
# MESSAGE LABEL
# ============================================================

class MessageLabel(QLabel):
    """A status message that fades in, waits, then fades out."""

    def __init__(self, parent=None):
        super().__init__(parent)

        # Centre the text and allow wrapping
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setWordWrap(True)
        self.setMinimumHeight(28)

        # Transparent look
        self.setStyleSheet(small_label_style(TEXT, 11, 600))

        # An opacity effect lets us animate the fade
        self.effect = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self.effect)
        self.effect.setOpacity(0.0)   # Start invisible

        self.animation = None

    def show_message(self, text, color, duration=3500):
        """Show text in the given colour, then fade it out after `duration` ms."""
        self.setText(text)
        self.setStyleSheet(small_label_style(color, 11, 600))

        # Fade in
        self.effect.setOpacity(0.0)
        self.animation = QPropertyAnimation(self.effect, b"opacity", self)
        self.animation.setDuration(320)
        self.animation.setStartValue(0.0)
        self.animation.setEndValue(1.0)
        self.animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        self.animation.start()

        # Schedule the fade out
        if duration:
            QTimer.singleShot(duration, self.fade_out)

    def fade_out(self):
        """Fade the message away and clear the text."""
        if not self.text():
            return

        self.animation = QPropertyAnimation(self.effect, b"opacity", self)
        self.animation.setDuration(450)
        self.animation.setStartValue(self.effect.opacity())
        self.animation.setEndValue(0.0)
        self.animation.setEasingCurve(QEasingCurve.Type.InCubic)
        self.animation.finished.connect(self.clear)
        self.animation.start()
