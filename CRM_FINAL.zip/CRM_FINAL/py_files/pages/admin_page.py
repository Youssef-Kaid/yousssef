
# pyright: reportOptionalMemberAccess=false, reportAttributeAccessIssue=false
"""
admin_page.py
-------------
Page 7: the Admin menu (Event Record, Mail)

"""
 
from PyQt6.QtWidgets import (
    QLabel, QLineEdit, QVBoxLayout, QGridLayout, QHeaderView, QMessageBox,
    QDialog, QDialogButtonBox, QTextEdit,
)
 
from py_files.core.config import ACCENTS
from py_files.core.helpers import small_label_style
from py_files.core.widgets import ActionButton, NavButton, GlassFrame
from py_files.core.tables import ScrollTable, style_table, populate_table
from py_files.core.base_page import BasePage
 
 
CALENDAR_ROWS = [
    ["2026-10-05", "Mentor Meeting", "10:00", "Scheduled"],
    ["2026-10-07", "Project Review", "14:00", "Pending"],
    ["2026-10-09", "Interview Day", "09:30", "Scheduled"],
    ["2026-10-12", "CRM Review", "15:00", "Scheduled"],
]
 
 
class AdminPage(BasePage):
    """Administrator menu."""
 
    def __init__(self, parent=None):
        super().__init__(ACCENTS["admin"], parent)
        self.build_ui()
 
    def build_ui(self):
        # Step 1: brand line and header
        self.add_top_brand()
        self.add_header(
            "ADMINISTRATION",
            "Admin Menu",
            "Manage administrator tools, event records, mail and calendar records.",
        )
 
        # Step 2: rounded frame with four buttons in a 2x2 grid
        actions_frame = GlassFrame(accent=self.accent, radius=20, opacity=90)
        actions_layout = QGridLayout(actions_frame)
        actions_layout.setContentsMargins(22, 22, 22, 30)   # extra bottom space
        actions_layout.setHorizontalSpacing(14)
        actions_layout.setVerticalSpacing(14)
 
        event_button = NavButton(
            "Event Record", "Review and create event records", self.accent
        )
        mail_button = NavButton("Mail", "Open the CRM mail interface", "#6366F1")
        preferences_button = NavButton(
            "Preferences", "Return to administrator workspace", ACCENTS["preferences"]
        )
        exit_button = NavButton("Exit", "Return to the login screen", "#EF4444")
 
        # Step 3: connect the buttons
        event_button.clicked.connect(self.show_event_record)
        mail_button.clicked.connect(self.show_mail)
        preferences_button.clicked.connect(self.return_preferences)
        exit_button.clicked.connect(self.exit_admin)
 
        actions_layout.addWidget(event_button, 0, 0)
        actions_layout.addWidget(mail_button, 0, 1)
        actions_layout.addWidget(preferences_button, 1, 0)
        actions_layout.addWidget(exit_button, 1, 1)
        self.main_layout.addWidget(actions_frame)
 
        # Step 4: small heading above the calendar table
        calendar_header = QLabel("CALENDAR RECORDS")
        calendar_header.setStyleSheet(small_label_style(self.accent, 11, 800, "1.2px"))
        self.main_layout.addWidget(calendar_header)
 
        # Step 5: rounded frame holding the EMPTY calendar table
        calendar_frame = GlassFrame(accent=self.accent, radius=18, opacity=80)
        calendar_layout = QVBoxLayout(calendar_frame)
        calendar_layout.setContentsMargins(2, 2, 2, 2)
 
        self.calendar_table = ScrollTable()
        self.calendar_table.setColumnCount(4)
        self.calendar_table.setHorizontalHeaderLabels(["Date", "Event", "Time", "Status"])
        style_table(self.calendar_table, self.accent)
        populate_table(self.calendar_table, CALENDAR_ROWS)
 
        # All four columns share the width equally
        header = self.calendar_table.horizontalHeader()
        for column in range(4):
            header.setSectionResizeMode(column, QHeaderView.ResizeMode.Stretch)
 
        calendar_layout.addWidget(self.calendar_table)
        self.main_layout.addWidget(calendar_frame, 1)
 
    # --------------------------------------------------------
    # Event Record pop-up
    # --------------------------------------------------------
    def show_event_record(self):
        """Open a small 'Create Event Record' dialog (UI only)."""
        dialog = QDialog(self)
        dialog.setWindowTitle("Event Record")
        dialog.resize(500, 420)
        dialog.setStyleSheet(
            "QDialog { background: #111827; } QLabel { color: #E2E8F0; }"
        )
        layout = QVBoxLayout(dialog)
 
        title = QLabel("Create Event Record")
        title.setStyleSheet(
            f"QLabel {{ color: {self.accent}; font-size: 18px; font-weight: 800; }}"
        )
 
        # Input fields
        event_name = QLineEdit()
        event_name.setPlaceholderText("Event name")
        event_date = QLineEdit()
        event_date.setPlaceholderText("Date")
        event_time = QLineEdit()
        event_time.setPlaceholderText("Time")
        notes = QTextEdit()
        notes.setPlaceholderText("Event notes...")
 
        # Save / Cancel buttons
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(
            lambda: self.save_event(dialog, event_name, event_date, event_time, notes)
        )
        buttons.rejected.connect(dialog.reject)
 
        layout.addWidget(title)
        layout.addWidget(event_name)
        layout.addWidget(event_date)
        layout.addWidget(event_time)
        layout.addWidget(notes)
        layout.addWidget(buttons)
 
        dialog.exec()
 
    def save_event(self, dialog, event_name, event_date, event_time, notes):
        """UI only: checks the name, shows a message and closes the dialog."""
        # An event needs at least a name
        if not event_name.text().strip():
            QMessageBox.warning(dialog, "Missing Event", "Please enter an event name.")
            return
 
        QMessageBox.information(
            dialog, "Event Saved", "The event has been added to the UI demo."
        )
        dialog.accept()
 
    # --------------------------------------------------------
    # Mail pop-up
    # --------------------------------------------------------
    def show_mail(self):
        """Open a mock mail window (UI only)."""
        dialog = QDialog(self)
        dialog.setWindowTitle("CRM Mail")
        dialog.resize(700, 500)
        dialog.setStyleSheet("QDialog { background: #111827; }")
        layout = QVBoxLayout(dialog)
 
        title = QLabel("MAIL")
        title.setStyleSheet(
            f"QLabel {{ color: {ACCENTS['admin']}; font-size: 19px; font-weight: 800; }}"
        )
 
        recipient = QLineEdit()
        recipient.setPlaceholderText("Recipient")
        subject = QLineEdit()
        subject.setPlaceholderText("Subject")
        message = QTextEdit()
        message.setPlaceholderText("Write your message...")
 
        # The SEND button only shows an information message
        send_button = ActionButton("SEND", ACCENTS["admin"], primary=True)
        send_button.clicked.connect(
            lambda: QMessageBox.information(
                dialog, "Mail Demo",
                "The mail interface is ready for backend integration.",
            )
        )
 
        layout.addWidget(title)
        layout.addWidget(recipient)
        layout.addWidget(subject)
        layout.addWidget(message)
        layout.addWidget(send_button)
 
        dialog.exec()
 
    # --------------------------------------------------------
    # Navigation buttons
    # --------------------------------------------------------
    def return_preferences(self):
        """Go back to the admin Preferences page."""
        self.window().show_preferences(True)
 
    def exit_admin(self):
        """Go back to the Sign-in page."""
        self.window().show_login()
 
