# pyright: reportOptionalMemberAccess=false, reportAttributeAccessIssue=false
"""
applications_page.py
--------------------
Page 4: the Applications page.

"""
 
import csv
 
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QAction
from PyQt6.QtWidgets import (
    QLabel, QLineEdit, QVBoxLayout, QHBoxLayout, QHeaderView, QMessageBox,
    QFileDialog, QComboBox, QDialog, QDialogButtonBox, QMenu,
)
 
from py_files.core.config import ACCENTS, BASE_DIR, MUTED, MUTED_2
from py_files.core.helpers import small_label_style
from py_files.core.widgets import ActionButton, GlassFrame
from py_files.core.tables import ScrollTable, style_table, populate_table
from py_files.core.base_page import BasePage
 
 
SAMPLE_APPLICATIONS = [
    ["A001", "Emma Johnson", "emma.johnson@example.com", "Python Developer", "Pending", "Defined", "2026-09-02"],
    ["A002", "Noah Williams", "noah.williams@example.com", "Data Analyst", "Accepted", "Defined", "2026-09-03"],
    ["A003", "Olivia Brown", "olivia.brown@example.com", "Web Developer", "Rejected", "Not Defined", "2026-09-04"],
    ["A004", "Liam Jones", "liam.jones@example.com", "Software Engineer", "Pending", "Defined", "2026-09-05"],
    ["A005", "Ava Garcia", "ava.garcia@example.com", "UX Designer", "Accepted", "Defined", "2026-09-06"],
    ["A006", "William Miller", "william.miller@example.com", "Python Developer", "Pending", "Not Defined", "2026-09-07"],
    ["A007", "Sophia Davis", "sophia.davis@example.com", "Project Manager", "Accepted", "Defined", "2026-09-08"],
    ["A008", "James Rodriguez", "james.rodriguez@example.com", "Data Analyst", "Rejected", "Not Defined", "2026-09-09"],
    ["A009", "Isabella Martinez", "isabella.martinez@example.com", "Backend Developer", "Pending", "Defined", "2026-09-10"],
    ["A010", "Benjamin Hernandez", "benjamin.h@example.com", "Frontend Developer", "Accepted", "Defined", "2026-09-11"],
    ["A011", "Mia Lopez", "mia.lopez@example.com", "UI Designer", "Pending", "Not Defined", "2026-09-12"],
    ["A012", "Lucas Gonzalez", "lucas.g@example.com", "Python Developer", "Rejected", "Defined", "2026-09-13"],
]
 
 
class ApplicationsPage(BasePage):
    """Applications page."""
 
    # Column titles of the table
    HEADERS = [
        "ID", "Applicant Name", "Email", "Position",
        "Status", "Mentor Meeting", "Date Applied",
    ]
 
    def __init__(self, is_admin=False, parent=None):
        super().__init__(ACCENTS["applications"], parent)
        self.is_admin = is_admin
 
        # Sample data restored from the original file
        self.all_rows = [row.copy() for row in SAMPLE_APPLICATIONS]
        self.filtered_rows = []
 
        self.build_ui()
        self.apply_filters()
 
    def build_ui(self):
        # Step 1: brand line and header
        self.add_top_brand()
        self.add_header(
            "CRM / APPLICATIONS",
            "Applications",
            "Search, filter and review applicant records from one workspace.",
        )
 
        # Step 2: toolbar frame (search + filter buttons)
        toolbar = GlassFrame(accent=self.accent, radius=17, opacity=105)
        toolbar_layout = QVBoxLayout(toolbar)
        toolbar_layout.setContentsMargins(16, 15, 16, 15)
        toolbar_layout.setSpacing(12)
 
        # Step 2a: search row = text box + SEARCH + CLEAR
        search_row = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText(
            "Search applications by name, email, position or status..."
        )
        self.search_input.setMinimumHeight(44)
 
        search_button = ActionButton("SEARCH", self.accent, primary=True)
        clear_button = ActionButton("CLEAR", self.accent)
        search_button.clicked.connect(self.apply_filters)
        clear_button.clicked.connect(self.clear_search)
        self.search_input.returnPressed.connect(self.apply_filters)
 
        search_row.addWidget(self.search_input, 1)
        search_row.addWidget(search_button)
        search_row.addWidget(clear_button)
        toolbar_layout.addLayout(search_row)
 
        # Step 2b: filter buttons row
        filter_row = QHBoxLayout()
        filter_buttons = [
            ("ALL APPLICATIONS", "all"),
            ("MENTOR MEETING DEFINED", "mentor_defined"),
            ("MENTOR MEETING NOT DEFINED", "mentor_not_defined"),
            ("PENDING", "pending"),
            ("ACCEPTED", "accepted"),
            ("REJECTED", "rejected"),
        ]
        for text, key in filter_buttons:
            button = ActionButton(text, self.accent)
            button.setMinimumHeight(38)
            # k=key makes every button remember its own filter name
            button.clicked.connect(lambda checked=False, k=key: self.set_filter(k))
            filter_row.addWidget(button)
 
        # EXPORT button at the end of the row
        export_button = ActionButton("EXPORT", self.accent)
        export_button.clicked.connect(self.export_csv)
        filter_row.addWidget(export_button)
        toolbar_layout.addLayout(filter_row)
 
        self.main_layout.addWidget(toolbar)
 
        # Step 3: row with the record count and a small hint
        count_row = QHBoxLayout()
        self.count_label = QLabel("0 applications")
        self.count_label.setStyleSheet(small_label_style(MUTED, 10, 600))
        hint_label = QLabel(
            "Double-click a row for details  \u2022  Right-click to edit status"
        )
        hint_label.setStyleSheet(small_label_style(MUTED_2, 9, 400))
        count_row.addWidget(self.count_label)
        count_row.addStretch()
        count_row.addWidget(hint_label)
        self.main_layout.addLayout(count_row)
 
        # Step 4: rounded frame that holds the table
        table_frame = GlassFrame(accent=self.accent, radius=18, opacity=80)
        table_layout = QVBoxLayout(table_frame)
        table_layout.setContentsMargins(2, 2, 2, 2)
 
        # Step 4a: the (empty) table with its header titles
        self.table = ScrollTable()
        self.table.setColumnCount(len(self.HEADERS))
        self.table.setHorizontalHeaderLabels(self.HEADERS)
        style_table(self.table, self.accent)
 
        # Step 4b: column widths (narrow columns fit content, others stretch)
        header = self.table.horizontalHeader()
        modes = {
            0: QHeaderView.ResizeMode.ResizeToContents,
            1: QHeaderView.ResizeMode.Stretch,
            2: QHeaderView.ResizeMode.Stretch,
            3: QHeaderView.ResizeMode.Stretch,
            4: QHeaderView.ResizeMode.ResizeToContents,
            5: QHeaderView.ResizeMode.ResizeToContents,
            6: QHeaderView.ResizeMode.ResizeToContents,
        }
        for column, mode in modes.items():
            header.setSectionResizeMode(column, mode)
 
        # Step 4c: double-click = details, right-click = context menu
        self.table.itemDoubleClicked.connect(self.show_details)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)
 
        table_layout.addWidget(self.table)
        self.main_layout.addWidget(table_frame, 1)
 
        # Step 5: bottom button returns to Preferences
        bottom_layout = QHBoxLayout()
        back_button = ActionButton("RETURN TO PREFERENCES", self.accent)
        back_button.clicked.connect(lambda: self.window().show_preferences(self.is_admin))
        bottom_layout.addWidget(back_button)
        bottom_layout.addStretch()
        self.main_layout.addLayout(bottom_layout)
 
    # --------------------------------------------------------
    # Searching and filtering
    # --------------------------------------------------------
    def clear_search(self):
        """Empty the search box and show all rows."""
        self.search_input.clear()
        self.apply_filters()
 
    def set_filter(self, filter_type):
        """Apply one of the preset filters on top of the search text."""
        search = self.search_input.text().strip().lower()
        rows = self.all_rows.copy()
 
        # Keep only rows containing the search text
        if search:
            rows = [r for r in rows if any(search in str(v).lower() for v in r)]
 
        # Apply the chosen preset filter
        if filter_type == "mentor_defined":
            rows = [r for r in rows if r[5].lower() == "defined"]
        elif filter_type == "mentor_not_defined":
            rows = [r for r in rows if r[5].lower() == "not defined"]
        elif filter_type == "pending":
            rows = [r for r in rows if r[4].lower() == "pending"]
        elif filter_type == "accepted":
            rows = [r for r in rows if r[4].lower() == "accepted"]
        elif filter_type == "rejected":
            rows = [r for r in rows if r[4].lower() == "rejected"]
 
        self.filtered_rows = rows
        populate_table(self.table, rows)
        self.update_count()
 
    def apply_filters(self):
        """Filter rows by the search text only."""
        search = self.search_input.text().strip().lower()
 
        if not search:
            self.filtered_rows = self.all_rows.copy()
        else:
            self.filtered_rows = [
                r for r in self.all_rows
                if any(search in str(v).lower() for v in r)
            ]
 
        populate_table(self.table, self.filtered_rows)
        self.update_count()
 
    def update_count(self):
        """Update the '0 applications' label."""
        count = len(self.filtered_rows)
        self.count_label.setText(f"{count} application" + ("" if count == 1 else "s"))
 
    # --------------------------------------------------------
    # Export
    # --------------------------------------------------------
    def export_csv(self):
        """Save the visible rows to a CSV file."""
        # Nothing to save
        if not self.filtered_rows:
            QMessageBox.information(
                self, "Nothing to Export",
                "There are no visible application records to export.",
            )
            return
 
        # Ask where to save
        filename, _ = QFileDialog.getSaveFileName(
            self, "Export Applications",
            str(BASE_DIR / "applications.csv"), "CSV Files (*.csv)",
        )
        if not filename:
            return
 
        # Write header + rows
        try:
            with open(filename, "w", newline="", encoding="utf-8") as file:
                writer = csv.writer(file)
                writer.writerow(self.HEADERS)
                writer.writerows(self.filtered_rows)
            QMessageBox.information(
                self, "Export Complete",
                f"Applications exported successfully.\n\n{filename}",
            )
        except OSError as error:
            QMessageBox.warning(self, "Export Error", str(error))
 
    # --------------------------------------------------------
    # Details, context menu and status editing
    # --------------------------------------------------------
    def show_details(self, item):
        """Show a pop-up with the selected row's details."""
        if item is None:
            return
 
        # Read every cell of the row
        row = item.row()
        values = []
        for column in range(self.table.columnCount()):
            cell = self.table.item(row, column)
            values.append(cell.text() if cell else "")
 
        QMessageBox.information(
            self, "Application Details",
            f"Applicant: {values[1]}\nEmail: {values[2]}\nPosition: {values[3]}\n"
            f"Status: {values[4]}\nMentor Meeting: {values[5]}\n"
            f"Date Applied: {values[6]}",
        )
 
    def show_context_menu(self, position):
        """Right-click menu: View Details / Edit Status."""
        item = self.table.itemAt(position)
        if item is None:
            return
        row = item.row()
 
        menu = QMenu(self)
        menu.setStyleSheet(
            f"""
            QMenu {{ background: #172033; color: #F8FAFC;
                     border: 1px solid {self.accent}; padding: 5px; }}
            QMenu::item {{ padding: 8px 24px; border-radius: 6px; }}
            QMenu::item:selected {{ background: rgba(59, 130, 246, 90); }}
            """
        )
 
        details_action = QAction("View Details", self)
        edit_action = QAction("Edit Status", self)
        menu.addAction(details_action)
        menu.addAction(edit_action)
 
        details_action.triggered.connect(lambda: self.show_details(self.table.item(row, 0)))
        edit_action.triggered.connect(lambda: self.edit_status(row))
 
        menu.exec(self.table.viewport().mapToGlobal(position))
 
    def edit_status(self, row):
        """Open a small dialog to change an application's status."""
        if row < 0:
            return
 
        # Read the current status and the application ID
        status_item = self.table.item(row, 4)
        id_item = self.table.item(row, 0)
        if status_item is None or id_item is None:
            return
        current_status = status_item.text()
        application_id = id_item.text()
 
        # Build the dialog
        dialog = QDialog(self)
        dialog.setWindowTitle("Edit Application Status")
        dialog.setMinimumWidth(340)
        dialog.setStyleSheet(
            f"""
            QDialog {{ background: #111827; }}
            QLabel {{ color: #E2E8F0; }}
            QComboBox {{ background: #172033; border: 1px solid {self.accent};
                         padding: 9px; border-radius: 8px; color: #F8FAFC; }}
            """
        )
        layout = QVBoxLayout(dialog)
        label = QLabel("Select the new application status:")
 
        combo = QComboBox()
        combo.addItems(["Pending", "Accepted", "Rejected"])
        index = combo.findText(current_status)
        if index >= 0:
            combo.setCurrentIndex(index)
 
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
 
        layout.addWidget(label)
        layout.addWidget(combo)
        layout.addWidget(buttons)
 
        # If OK was pressed, save the new status and refresh the table
        if dialog.exec() == QDialog.DialogCode.Accepted:
            for data_row in self.all_rows:
                if data_row[0] == application_id:
                    data_row[4] = combo.currentText()
                    break
            self.apply_filters()
 
