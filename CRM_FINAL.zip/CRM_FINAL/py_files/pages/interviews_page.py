
# pyright: reportOptionalMemberAccess=false, reportAttributeAccessIssue=false
"""
interviews_page.py
------------------
Page 6: the Interviews page.
 
"""
 
from PyQt6.QtWidgets import QLineEdit, QVBoxLayout, QHBoxLayout, QHeaderView
 
from py_files.core.config import ACCENTS
from py_files.core.widgets import ActionButton, GlassFrame
from py_files.core.tables import ScrollTable, style_table, populate_table
from py_files.core.base_page import BasePage
 
 
INTERVIEW_DATA = [
    ["I001", "Emma Johnson", "Python Developer", "Project Sent", "2026-09-15"],
    ["I002", "Noah Williams", "Data Analyst", "Project Received", "2026-09-16"],
    ["I003", "Liam Jones", "Software Engineer", "Project Sent", "2026-09-17"],
    ["I004", "Ava Garcia", "UX Designer", "Project Received", "2026-09-18"],
    ["I005", "Sophia Davis", "Project Manager", "Project Sent", "2026-09-19"],
    ["I006", "Benjamin Hernandez", "Frontend Developer", "Project Received", "2026-09-20"],
]
 
 
class InterviewsPage(BasePage):
    """Interviews page."""
 
    def __init__(self, is_admin=False, parent=None):
        super().__init__(ACCENTS["interviews"], parent)
        self.is_admin = is_admin
 
        # Sample data restored from the original file
        self.rows = [row.copy() for row in INTERVIEW_DATA]
 
        # Which status filter is active: "all", "sent" or "received"
        self.current_filter = "all"
 
        self.build_ui()
        self.apply_filters()
 
    def build_ui(self):
        # Step 1: brand line and header
        self.add_top_brand()
        self.add_header(
            "CRM / INTERVIEWS",
            "Interviews",
            "Track project delivery stages and interview progress.",
        )
 
        # Step 2: toolbar frame
        toolbar = GlassFrame(accent=self.accent, radius=17, opacity=105)
        toolbar_layout = QVBoxLayout(toolbar)
        toolbar_layout.setContentsMargins(16, 15, 16, 15)
        toolbar_layout.setSpacing(12)
 
        # Step 2a: search row
        search_row = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText(
            "Search interviews, applicants or positions..."
        )
        self.search_input.setMinimumHeight(44)
 
        search_button = ActionButton("SEARCH", self.accent, primary=True)
        search_button.clicked.connect(self.apply_filters)
        self.search_input.returnPressed.connect(self.apply_filters)
 
        search_row.addWidget(self.search_input, 1)
        search_row.addWidget(search_button)
        toolbar_layout.addLayout(search_row)
 
        # Step 2b: three status-filter buttons
        filter_row = QHBoxLayout()
        all_button = ActionButton("ALL INTERVIEWS", self.accent)
        sent_button = ActionButton("PROJECT SENT", self.accent)
        received_button = ActionButton("PROJECT RECEIVED", self.accent)
 
        all_button.clicked.connect(lambda: self.set_filter("all"))
        sent_button.clicked.connect(lambda: self.set_filter("sent"))
        received_button.clicked.connect(lambda: self.set_filter("received"))
 
        filter_row.addWidget(all_button)
        filter_row.addWidget(sent_button)
        filter_row.addWidget(received_button)
        filter_row.addStretch()
        toolbar_layout.addLayout(filter_row)
 
        self.main_layout.addWidget(toolbar)
 
        # Step 3: rounded frame that holds the table
        table_frame = GlassFrame(accent=self.accent, radius=18, opacity=80)
        table_layout = QVBoxLayout(table_frame)
        table_layout.setContentsMargins(2, 2, 2, 2)
 
        # Step 3a: the (empty) table with its header titles
        self.table = ScrollTable()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(
            ["ID", "Applicant", "Position", "Project Status", "Date"]
        )
        style_table(self.table, self.accent)
 
        # Step 3b: ID column fits its content, the others share the space
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        for column in range(1, 5):
            header.setSectionResizeMode(column, QHeaderView.ResizeMode.Stretch)
 
        table_layout.addWidget(self.table)
        self.main_layout.addWidget(table_frame, 1)
 
        # Step 4: bottom button returns to Preferences
        bottom_layout = QHBoxLayout()
        back_button = ActionButton("RETURN TO PREFERENCES", self.accent)
        back_button.clicked.connect(lambda: self.window().show_preferences(self.is_admin))
        bottom_layout.addWidget(back_button)
        bottom_layout.addStretch()
        self.main_layout.addLayout(bottom_layout)
 
    def set_filter(self, filter_type):
        """Remember the chosen status filter and refresh the table."""
        self.current_filter = filter_type
        self.apply_filters()
 
    def apply_filters(self):
        """Filter rows by the search text and the status filter."""
        search = self.search_input.text().strip().lower()
 
        rows = []
        for row in self.rows:
            # Does any cell contain the search text?
            matches_search = not search or any(search in str(v).lower() for v in row)
 
            # Does the project status match the chosen filter?
            if self.current_filter == "sent":
                matches_status = row[3] == "Project Sent"
            elif self.current_filter == "received":
                matches_status = row[3] == "Project Received"
            else:
                matches_status = True
 
            if matches_search and matches_status:
                rows.append(row)
 
        populate_table(self.table, rows)
 
