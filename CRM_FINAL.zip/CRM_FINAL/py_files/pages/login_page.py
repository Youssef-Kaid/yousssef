"""
login_page.py
-------------
Page 1: the Sign-in page.

(UI prototype - created with AI assistance, see main.py.)
"""

from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtWidgets import (
    QFrame, QLabel, QPushButton, QLineEdit, QVBoxLayout, QHBoxLayout, QCheckBox,
)

from py_files.core.config import ACCENTS, TEXT, TEXT_SOFT, MUTED
from py_files.core.helpers import load_users, verify_password, get_app_settings, small_label_style
from py_files.core.widgets import ActionButton, MessageLabel
from py_files.core.base_page import BasePage, build_auth_layout


class LoginPage(BasePage):
    """Sign-in page."""

    # Signals tell MainWindow what the user wants to do
    login_success = pyqtSignal(str, bool)   # (username, is_admin)
    signup_requested = pyqtSignal()         # "Create account" clicked
    close_requested = pyqtSignal()          # "Close application" clicked

    def __init__(self, parent=None):
        super().__init__(ACCENTS["login"], parent)

        # Load saved accounts and the settings object
        self.users = load_users()
        self.settings = get_app_settings()

        # Build the screen, then restore the remembered username
        self.build_ui()
        self.load_remembered_username()

    # --------------------------------------------------------
    # Build the interface
    # --------------------------------------------------------
    def build_ui(self):
        # The right-hand form panel and its vertical layout
        panel = QFrame()
        panel_layout = QVBoxLayout(panel)
        panel_layout.setContentsMargins(38, 40, 38, 30)
        panel_layout.setSpacing(12)

        # Title and subtitle
        title = QLabel("Welcome back")
        title.setStyleSheet(small_label_style(TEXT, 30, 800))
        panel_layout.addWidget(title)

        subtitle = QLabel("Sign in to continue to your CRM workspace.")
        subtitle.setWordWrap(True)
        subtitle.setStyleSheet(small_label_style(TEXT_SOFT, 13, 400))
        panel_layout.addWidget(subtitle)

        panel_layout.addSpacing(18)

        # Username box
        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("Username")
        self.username_input.setMinimumHeight(48)
        panel_layout.addWidget(self.username_input)

        # Password box (characters hidden)
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Password")
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_input.setMinimumHeight(48)
        panel_layout.addWidget(self.password_input)

        # Row with the two check boxes
        options_layout = QHBoxLayout()
        self.remember_checkbox = QCheckBox("Remember me")
        self.show_password_checkbox = QCheckBox("Show password")
        self.show_password_checkbox.stateChanged.connect(self.toggle_password)
        options_layout.addWidget(self.remember_checkbox)
        options_layout.addStretch()
        options_layout.addWidget(self.show_password_checkbox)
        panel_layout.addLayout(options_layout)

        # Area where success / error messages appear
        self.message_label = MessageLabel()
        panel_layout.addWidget(self.message_label)

        # Main "Sign in" button
        self.login_button = ActionButton("Sign in  \u2192", self.accent, primary=True)
        self.login_button.setMinimumHeight(52)
        self.login_button.clicked.connect(self.login)
        panel_layout.addWidget(self.login_button)

        # "Create account" button opens the Sign-up page
        self.signup_button = ActionButton("Create account", self.accent)
        self.signup_button.clicked.connect(self.signup_requested.emit)
        panel_layout.addWidget(self.signup_button)

        # Small "Forgot your password?" link
        forgot_button = QPushButton("Forgot your password?")
        forgot_button.setCursor(Qt.CursorShape.PointingHandCursor)
        forgot_button.setStyleSheet(
            f"""
            QPushButton {{
                background: transparent; border: none;
                color: {TEXT_SOFT}; font-size: 11px; padding: 6px;
            }}
            QPushButton:hover {{ color: #FFFFFF; }}
            QPushButton:pressed {{ color: {self.accent}; }}
            """
        )
        forgot_button.clicked.connect(self.forgot_password)
        panel_layout.addWidget(forgot_button, 0, Qt.AlignmentFlag.AlignHCenter)

        # Push the bottom items down
        panel_layout.addStretch()

        # Centred demo-accounts hint
        demo_label = QLabel("Demo access:  admin / admin123   \u2022   user / user123")
        demo_label.setWordWrap(True)
        demo_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        demo_label.setStyleSheet(small_label_style(MUTED, 11, 400))
        panel_layout.addWidget(demo_label)

        panel_layout.addSpacing(6)

        # "Close application" button at the very bottom
        close_button = ActionButton("Close application", self.accent)
        close_button.clicked.connect(self.close_requested.emit)
        panel_layout.addWidget(close_button)

        # Place the left brand card and this panel on the page
        build_auth_layout(
            self,
            panel,
            self.accent,
            "CRM\nWorkspace",
            "A clean workspace for managing applications, mentor "
            "conversations, interviews and events.",
            [
                "Search, filter and export applications",
                "Review mentor conversations",
                "Track interviews and calendar events",
            ],
        )

        # Pressing Enter in either box also signs in
        self.password_input.returnPressed.connect(self.login)
        self.username_input.returnPressed.connect(self.login)

    # --------------------------------------------------------
    # "Remember me"
    # --------------------------------------------------------
    def load_remembered_username(self):
        """Fill in the username that was remembered last time."""
        remembered = self.settings.value("remembered_username", "", type=str)
        if remembered:
            self.username_input.setText(remembered)
            self.remember_checkbox.setChecked(True)

    def save_remembered_username(self):
        """Save the username if 'Remember me' is ticked, otherwise forget it."""
        if self.remember_checkbox.isChecked():
            self.settings.setValue(
                "remembered_username", self.username_input.text().strip()
            )
        else:
            self.settings.remove("remembered_username")

    # --------------------------------------------------------
    # Small actions
    # --------------------------------------------------------
    def toggle_password(self):
        """Show or hide the typed password."""
        if self.show_password_checkbox.isChecked():
            self.password_input.setEchoMode(QLineEdit.EchoMode.Normal)
        else:
            self.password_input.setEchoMode(QLineEdit.EchoMode.Password)

    def forgot_password(self):
        """UI-only: just show an information message."""
        self.message_label.show_message(
            "Password recovery is part of a future backend phase.", "#93C5FD"
        )

    def _succeed(self, text, username, is_admin):
        """Show a green message, then tell MainWindow to open the next page."""
        self.save_remembered_username()
        self.message_label.show_message(text, "#4ADE80", duration=1200)
        QTimer.singleShot(550, lambda: self.login_success.emit(username, is_admin))

    # --------------------------------------------------------
    # Login logic
    # --------------------------------------------------------
    def login(self):
        """
        Check the typed credentials.

        Demo accounts:
            admin / admin123
            user  / user123
        Accounts created on the Sign-up page are also accepted.
        """
        # Reload so accounts created a moment ago work immediately
        self.users = load_users()

        # Read what the user typed
        username = self.username_input.text().strip()
        password = self.password_input.text()

        # Step 1: both boxes must be filled in
        if not username or not password:
            self.message_label.show_message(
                "Please enter both your username and password.", "#F87171"
            )
            return

        # Step 2: built-in admin demo account
        if username.lower() == "admin" and password == "admin123":
            self._succeed("Login successful. Opening Admin Workspace...", "admin", True)
            return

        # Step 3: built-in standard demo account
        if username.lower() == "user" and password == "user123":
            self._succeed("Login successful. Opening CRM Workspace...", "user", False)
            return

        # Step 4: accounts saved in users.json
        record = self.users.get(username)
        if record:
            salt = record.get("salt")
            stored_hash = record.get("hash")
            if salt and stored_hash and verify_password(password, salt, stored_hash):
                self._succeed(
                    "Login successful.", username, bool(record.get("admin", False))
                )
                return

        # Step 5: nothing matched
        self.message_label.show_message("Incorrect username or password.", "#F87171")

    def clear_form(self):
        """Reset the form (keeps the remembered username if enabled)."""
        remembered = self.settings.value("remembered_username", "", type=str)
        self.username_input.setText(remembered)
        self.remember_checkbox.setChecked(bool(remembered))
        self.password_input.clear()
        self.show_password_checkbox.setChecked(False)
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
