

# pyright: reportOptionalMemberAccess=false, reportAttributeAccessIssue=false
"""
mentor_page.py
--------------
Page 5: the Mentor Interview page.

"""
 
from PyQt6.QtWidgets import (
    QLineEdit, QVBoxLayout, QHBoxLayout, QHeaderView, QComboBox, QDialog,
    QDialogButtonBox, QLabel, QListWidget, QListWidgetItem, QListView,
)
 
from py_files.core.config import ACCENTS
from py_files.core.widgets import ActionButton, GlassFrame
from py_files.core.tables import ScrollTable, style_table, populate_table
from py_files.core.base_page import BasePage
 
 
MENTOR_CONVERSATIONS = [
    ["M001", "Emma Johnson", "Mentor A", "Initial Interview", "Positive", "2026-09-12"],
    ["M002", "Noah Williams", "Mentor B", "Technical Discussion", "Positive", "2026-09-13"],
    ["M003", "Liam Jones", "Mentor C", "Career Discussion", "Pending", "2026-09-14"],
    ["M004", "Ava Garcia", "Mentor A", "Project Discussion", "Positive", "2026-09-15"],
    ["M005", "Sophia Davis", "Mentor D", "Follow-up", "Pending", "2026-09-16"],
    ["M006", "Lucas Gonzalez", "Mentor B", "Technical Discussion", "Needs Review", "2026-09-17"],
]
 
 
class MentorInterviewPage(BasePage):
    """Mentor Interview page."""
 
    def __init__(self, is_admin=False, parent=None):
        super().__init__(ACCENTS["mentor"], parent)
        self.is_admin = is_admin
 
        # Categories shown in the drop-down (the first one means "no filter")
        self.categories = [
            "All Conversations",
            "Initial Interview",
            "Technical Discussion",
            "Career Discussion",
            "Project Discussion",
            "Follow-up",
        ]
 
        # Sample data restored from the original file
        self.rows = [row.copy() for row in MENTOR_CONVERSATIONS]
 
        self.build_ui()
        self.apply_filters()
 
    def build_ui(self):
        # Step 1: brand line and header
        self.add_top_brand()
        self.add_header(
            "CRM / MENTOR INTERVIEW",
            "Mentor Interview",
            "Review mentor conversations and organize interview discussions.",
        )
 
        # Step 2: toolbar frame (search box + SEARCH + category drop-down)
        toolbar = GlassFrame(accent=self.accent, radius=17, opacity=105)
        toolbar_layout = QVBoxLayout(toolbar)
        toolbar_layout.setContentsMargins(16, 15, 16, 15)
        toolbar_layout.setSpacing(12)
 
        search_row = QHBoxLayout()
 
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText(
            "Search conversations, applicants or mentors..."
        )
        self.search_input.setMinimumHeight(44)
 
        search_button = ActionButton("SEARCH", self.accent, primary=True)
        search_button.clicked.connect(self.apply_filters)
        self.search_input.returnPressed.connect(self.apply_filters)
 
        # Category drop-down. A plain QListView gives a clean popup list.
        self.category_combo = QComboBox()
        self.category_combo.setView(QListView())
        self.category_combo.setMaxVisibleItems(10)
        self.category_combo.addItems(self.categories + ["Edit Items"])
        self.category_combo.setMinimumWidth(230)
        self.category_combo.currentTextChanged.connect(self.category_changed)
 
        search_row.addWidget(self.search_input, 1)
        search_row.addWidget(search_button)
        search_row.addWidget(self.category_combo)
        toolbar_layout.addLayout(search_row)
        self.main_layout.addWidget(toolbar)
 
        # Step 3: rounded frame that holds the table
        table_frame = GlassFrame(accent=self.accent, radius=18, opacity=80)
        table_layout = QVBoxLayout(table_frame)
        table_layout.setContentsMargins(2, 2, 2, 2)
 
        # Step 3a: the (empty) table with its header titles
        self.table = ScrollTable()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(
            ["ID", "Applicant", "Mentor", "Conversation", "Status", "Date"]
        )
        style_table(self.table, self.accent)
 
        # Step 3b: ID column fits its content, the others share the space
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        for column in range(1, 6):
            header.setSectionResizeMode(column, QHeaderView.ResizeMode.Stretch)
 
        table_layout.addWidget(self.table)
        self.main_layout.addWidget(table_frame, 1)
 
        # Step 4: bottom button returns to Preferences
        bottom_layout = QHBoxLayout()
        back_button = ActionButton("RETURN TO PREFERENCES", self.accent)
        back_button.clicked.connect(lambda: self.window().show_preferences(self.is_admin))
        bottom_layout.addWidget(back_button)
        bottom_layout.addStretch()
        self.main_layout.addLayout(bottom_layout)
 
    # --------------------------------------------------------
    # Category drop-down
    # --------------------------------------------------------
    def category_changed(self, text):
        """React to a new drop-down choice."""
        # "Edit Items" opens the editor, then jumps back to the first item
        if text == "Edit Items":
            self.edit_categories()
            self.category_combo.setCurrentIndex(0)
            return
        self.apply_filters()
 
    def edit_categories(self):
        """Small dialog to add or remove categories (UI only)."""
        # Build the dialog window
        dialog = QDialog(self)
        dialog.setWindowTitle("Edit Conversation Categories")
        dialog.resize(450, 420)
        dialog.setStyleSheet(
            f"""
            QDialog {{ background: #111827; }}
            QLabel {{ color: #E2E8F0; }}
            QListWidget {{ background: #172033; border: 1px solid {self.accent}; }}
            """
        )
        layout = QVBoxLayout(dialog)
 
        title = QLabel("Conversation Categories")
        title.setStyleSheet(
            f"QLabel {{ color: {self.accent}; font-size: 16px; font-weight: 700; }}"
        )
 
        # List of editable categories (everything except "All Conversations")
        list_widget = QListWidget()
        for category in self.categories:
            if category != "All Conversations":
                list_widget.addItem(QListWidgetItem(category))
 
        # Row: new-category box + ADD + REMOVE
        input_layout = QHBoxLayout()
        input_field = QLineEdit()
        input_field.setPlaceholderText("New category")
        add_button = ActionButton("ADD", self.accent, primary=True)
        remove_button = ActionButton("REMOVE", self.accent)
        input_layout.addWidget(input_field, 1)
        input_layout.addWidget(add_button)
        input_layout.addWidget(remove_button)
 
        # Close button
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.rejected.connect(dialog.reject)
        buttons.accepted.connect(dialog.accept)
 
        def add_category():
            """Add the typed category if it is new."""
            text = input_field.text().strip()
            if not text:
                return
            existing = [list_widget.item(i).text() for i in range(list_widget.count())]
            if text not in existing:
                list_widget.addItem(text)
                input_field.clear()
 
        def remove_category():
            """Remove the selected category."""
            selected = list_widget.currentRow()
            if selected >= 0:
                list_widget.takeItem(selected)
 
        add_button.clicked.connect(add_category)
        remove_button.clicked.connect(remove_category)
 
        layout.addWidget(title)
        layout.addWidget(list_widget)
        layout.addLayout(input_layout)
        layout.addWidget(buttons)
 
        # Show the dialog and wait until it is closed
        dialog.exec()
 
        # Rebuild the category list from what is in the dialog
        new_categories = [list_widget.item(i).text() for i in range(list_widget.count())]
        self.categories = ["All Conversations"] + new_categories
 
        # Refill the drop-down without triggering currentTextChanged
        self.category_combo.blockSignals(True)
        self.category_combo.clear()
        self.category_combo.addItems(self.categories + ["Edit Items"])
        self.category_combo.setCurrentIndex(0)
        self.category_combo.blockSignals(False)
 
        self.apply_filters()
 
    # --------------------------------------------------------
    # Searching and filtering
    # --------------------------------------------------------
    def apply_filters(self):
        """Filter rows by the search text and the chosen category."""
        search = self.search_input.text().strip().lower()
        category = self.category_combo.currentText()
 
        rows = []
        for row in self.rows:
            # Does any cell contain the search text?
            matches_search = not search or any(search in str(v).lower() for v in row)
            # Does the conversation type match the category?
            matches_category = category == "All Conversations" or row[3] == category
            if matches_search and matches_category:
                rows.append(row)
 
        populate_table(self.table, rows)
 
