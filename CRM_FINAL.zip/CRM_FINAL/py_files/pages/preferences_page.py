"""
preferences_page.py
-------------------
Page 3: the Preferences page (used for both the standard user and the admin).

(UI prototype - created with AI assistance, see main.py.)
"""

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QLabel, QVBoxLayout, QHBoxLayout, QGridLayout

from py_files.core.config import ACCENTS, TEXT_SOFT
from py_files.core.helpers import small_label_style
from py_files.core.widgets import ActionButton, NavButton, StatusCard, GlassFrame, WelcomeBanner
from py_files.core.base_page import BasePage


class PreferencesPage(BasePage):
    """Preferences page. is_admin=True shows the admin version."""

    def __init__(self, is_admin=False, parent=None):
        super().__init__(ACCENTS["preferences"], parent)
        self.is_admin = is_admin
        self.build_ui()

    def build_ui(self):
        # The banner only exists on the admin page
        self.welcome_banner = None
        self.main_layout.setSpacing(14)

        # Step 1: brand line and page header
        self.add_top_brand()
        if self.is_admin:
            self.add_header(
                "ADMIN WORKSPACE",
                "Preferences",
                "Choose a CRM area to manage from the administrator workspace.",
            )
        else:
            self.add_header(
                "USER WORKSPACE",
                "Preferences",
                "Choose a CRM area to continue working with the application interface.",
            )

        # Step 2: the three navigation buttons
        applications_button = NavButton(
            "Applications", "View and filter applications", ACCENTS["applications"]
        )
        mentor_button = NavButton(
            "Mentor Interview", "Review mentor conversations", ACCENTS["mentor"]
        )
        interviews_button = NavButton(
            "Interviews", "Track project interview stages", ACCENTS["interviews"]
        )

        # Step 3: connect them to MainWindow. The lambda waits until the
        # click to call self.window(), because the page is not inside
        # MainWindow yet while it is being built.
        applications_button.clicked.connect(
            lambda: self.window().show_applications(self.is_admin)
        )
        mentor_button.clicked.connect(
            lambda: self.window().show_mentor(self.is_admin)
        )
        interviews_button.clicked.connect(
            lambda: self.window().show_interviews(self.is_admin)
        )

        # Step 4: rounded frame; extra bottom padding keeps space under the buttons
        navigation_frame = GlassFrame(accent=self.accent, radius=26, opacity=150)
        frame_layout = QVBoxLayout(navigation_frame)
        frame_layout.setContentsMargins(22, 22, 22, 30)
        frame_layout.setSpacing(0)

        if self.is_admin:
            # Admin: four equal buttons in a 2x2 grid
            admin_button = NavButton(
                "Admin", "Open administrator controls", ACCENTS["admin"]
            )
            admin_button.clicked.connect(self.open_admin)

            grid = QGridLayout()
            grid.setHorizontalSpacing(16)
            grid.setVerticalSpacing(16)
            grid.addWidget(applications_button, 0, 0)
            grid.addWidget(mentor_button, 0, 1)
            grid.addWidget(interviews_button, 1, 0)
            grid.addWidget(admin_button, 1, 1)
            frame_layout.addLayout(grid)
        else:
            # User: three buttons in a column
            column = QVBoxLayout()
            column.setSpacing(14)
            column.addWidget(applications_button)
            column.addWidget(mentor_button)
            column.addWidget(interviews_button)
            frame_layout.addLayout(column)

        self.main_layout.addWidget(navigation_frame)

        # Step 5a: admin only - the welcome banner
        if self.is_admin:
            self.welcome_banner = WelcomeBanner(ACCENTS["admin"], "Administrator")
            self.main_layout.addWidget(self.welcome_banner)

        # Step 5b: user only - two solid cards of the same size and colour
        if not self.is_admin:
            role_layout = QHBoxLayout()
            role_layout.setSpacing(16)
            role_layout.addWidget(
                StatusCard("User Workspace", "Standard CRM workspace",
                           ACCENTS["preferences"]), 1,
            )
            role_layout.addWidget(
                StatusCard("Standard User", "Administrative controls are not active.",
                           ACCENTS["preferences"]), 1,
            )
            self.main_layout.addLayout(role_layout)

        # Step 6: flexible space, small footer label and the CLOSE button
        self.main_layout.addStretch()

        week_label = QLabel("Week 5 \u2014 UI Design")
        week_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        week_label.setStyleSheet(small_label_style(TEXT_SOFT, 11, 700))
        self.main_layout.addWidget(week_label)

        bottom_layout = QHBoxLayout()
        bottom_layout.addStretch()
        close_button = ActionButton("CLOSE", self.accent)
        close_button.clicked.connect(lambda: self.window().show_login())
        bottom_layout.addWidget(close_button)
        self.main_layout.addLayout(bottom_layout)

    def set_user(self, username):
        """Update the welcome banner (admin page only)."""
        if self.welcome_banner is not None:
            self.welcome_banner.set_user(username)

    def open_admin(self):
        """Open the Admin menu."""
        self.window().show_admin()
