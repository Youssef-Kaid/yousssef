"""
signup_page.py
--------------
Page 2: the Create account (Sign-up) page.

(UI prototype - created with AI assistance, see main.py.)
"""

from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtWidgets import QFrame, QLabel, QLineEdit, QVBoxLayout, QHBoxLayout, QCheckBox

from py_files.core.config import ACCENTS, TEXT, TEXT_SOFT, MUTED
from py_files.core.helpers import load_users, save_users, hash_password, small_label_style
from py_files.core.widgets import ActionButton, MessageLabel
from py_files.core.base_page import BasePage, build_auth_layout


class SignupPage(BasePage):
    """Account creation page."""

    # Tells MainWindow to go back to the Sign-in page
    back_requested = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(ACCENTS["signup"], parent)

        # Load existing accounts, then build the screen
        self.users = load_users()
        self.build_ui()

    # --------------------------------------------------------
    # Build the interface
    # --------------------------------------------------------
    def build_ui(self):
        # Right-hand form panel
        panel = QFrame()
        panel_layout = QVBoxLayout(panel)
        panel_layout.setContentsMargins(38, 40, 38, 30)
        panel_layout.setSpacing(12)

        # Title and subtitle
        title = QLabel("Create account")
        title.setStyleSheet(small_label_style(TEXT, 30, 800))
        panel_layout.addWidget(title)

        subtitle = QLabel("Set up a local CRM account to get started.")
        subtitle.setWordWrap(True)
        subtitle.setStyleSheet(small_label_style(TEXT_SOFT, 13, 400))
        panel_layout.addWidget(subtitle)

        panel_layout.addSpacing(18)

        # First name and last name side by side
        name_layout = QHBoxLayout()
        name_layout.setSpacing(12)
        self.first_name_input = QLineEdit()
        self.last_name_input = QLineEdit()
        self.first_name_input.setPlaceholderText("First name")
        self.last_name_input.setPlaceholderText("Last name")
        self.first_name_input.setMinimumHeight(48)
        self.last_name_input.setMinimumHeight(48)
        name_layout.addWidget(self.first_name_input)
        name_layout.addWidget(self.last_name_input)
        panel_layout.addLayout(name_layout)

        # Username
        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("Username")
        self.username_input.setMinimumHeight(48)
        panel_layout.addWidget(self.username_input)

        # Password
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Password")
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_input.setMinimumHeight(48)
        panel_layout.addWidget(self.password_input)

        # Confirm password
        self.confirm_input = QLineEdit()
        self.confirm_input.setPlaceholderText("Confirm password")
        self.confirm_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.confirm_input.setMinimumHeight(48)
        panel_layout.addWidget(self.confirm_input)

        # "Show passwords" check box
        self.show_password_checkbox = QCheckBox("Show passwords")
        self.show_password_checkbox.stateChanged.connect(self.toggle_password)
        panel_layout.addWidget(self.show_password_checkbox)

        # Area for success / error messages
        self.message_label = MessageLabel()
        panel_layout.addWidget(self.message_label)

        # "Create account" button
        create_button = ActionButton("Create account  \u2192", self.accent, primary=True)
        create_button.setMinimumHeight(52)
        create_button.clicked.connect(self.create_account)
        panel_layout.addWidget(create_button)

        # Push the bottom items down
        panel_layout.addStretch()

        # Centred security note
        info = QLabel("Passwords are stored locally using PBKDF2-HMAC-SHA256.")
        info.setWordWrap(True)
        info.setAlignment(Qt.AlignmentFlag.AlignCenter)
        info.setStyleSheet(small_label_style(MUTED, 11, 400))
        panel_layout.addWidget(info)

        panel_layout.addSpacing(6)

        # "Back to sign in" button
        back_button = ActionButton("Back to sign in", self.accent)
        back_button.clicked.connect(self.back_requested.emit)
        panel_layout.addWidget(back_button)

        # Place the left brand card and this panel on the page
        build_auth_layout(
            self,
            panel,
            self.accent,
            "Join the\nCRM Workspace",
            "Create your account to start managing applications, "
            "mentor conversations, interviews and events in one place.",
            [
                "Quick setup, it takes under a minute",
                "Passwords are securely hashed",
                "Sign in right after you register",
            ],
        )

    # --------------------------------------------------------
    # Small actions
    # --------------------------------------------------------
    def toggle_password(self):
        """Show or hide both password boxes together."""
        if self.show_password_checkbox.isChecked():
            mode = QLineEdit.EchoMode.Normal
        else:
            mode = QLineEdit.EchoMode.Password
        self.password_input.setEchoMode(mode)
        self.confirm_input.setEchoMode(mode)

    # --------------------------------------------------------
    # Create the account
    # --------------------------------------------------------
    def create_account(self):
        """Validate the form and save a new local account."""
        # Always start from the latest saved accounts
        self.users = load_users()

        # Read the form
        first_name = self.first_name_input.text().strip()
        last_name = self.last_name_input.text().strip()
        username = self.username_input.text().strip()
        password = self.password_input.text()
        confirm = self.confirm_input.text()

        # Check 1: every field is filled
        if not all([first_name, last_name, username, password, confirm]):
            self.message_label.show_message("Please complete all fields.", "#F87171")
            return

        # Check 2: username length
        if len(username) < 3:
            self.message_label.show_message(
                "Username must contain at least 3 characters.", "#F87171"
            )
            return

        # Check 3: password length
        if len(password) < 6:
            self.message_label.show_message(
                "Password must contain at least 6 characters.", "#F87171"
            )
            return

        # Check 4: both passwords match
        if password != confirm:
            self.message_label.show_message("Passwords do not match.", "#F87171")
            return

        # Check 5: username not already used (the demo names are reserved)
        existing = {key.lower() for key in self.users} | {"admin", "user"}
        if username.lower() in existing:
            self.message_label.show_message("That username already exists.", "#F87171")
            return

        # Hash the password and store the new account
        salt, password_hash = hash_password(password)
        self.users[username] = {
            "first_name": first_name,
            "last_name": last_name,
            "salt": salt,
            "hash": password_hash,
            "admin": False,
        }

        # Save to users.json
        if not save_users(self.users):
            self.message_label.show_message(
                "Could not save the account locally.", "#F87171"
            )
            return

        # Success: show a message, then return to the Sign-in page
        self.message_label.show_message(
            "Account created successfully. Returning to login...",
            "#4ADE80",
            duration=1300,
        )
        QTimer.singleShot(1000, self.back_requested.emit)

    def clear_form(self):
        """Empty every field and hide the passwords."""
        self.first_name_input.clear()
        self.last_name_input.clear()
        self.username_input.clear()
        self.password_input.clear()
        self.confirm_input.clear()
        self.show_password_checkbox.setChecked(False)
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.confirm_input.setEchoMode(QLineEdit.EchoMode.Password)
