# UI design files (Qt Designer)

One `.ui` file per page. Each one is a visual design of the page
(layout, colours, sizes). The tables are empty, only the headers.

| File | Page |
|---|---|
| login_page.ui | 1. Sign in |
| signup_page.ui | 2. Create account |
| preferences_user.ui | 3. Preferences (standard user) |
| preferences_admin.ui | 3. Preferences (admin, with welcome banner) |
| applications_page.ui | 4. Applications |
| mentor_page.ui | 5. Mentor Interview |
| interviews_page.ui | 6. Interviews |
| admin_page.ui | 7. Admin menu |

## Preview a design (VS Code terminal, inside the CRM_App folder)

    python preview_ui.py ui/login_page.ui

## Edit a design visually

VS Code cannot draw .ui files by itself. Use Qt Designer, a separate
free tool that works well next to VS Code:

    pip install PySide6
    pyside6-designer ui/login_page.ui

(The .ui files it saves also work with PyQt6.)
You can also search "Qt for Python" in the VS Code Extensions panel:
some extensions add a "open in Qt Designer" option when you
right-click a .ui file.

## Use a design inside your code

    from PyQt6 import uic
    from PyQt6.QtWidgets import QWidget

    class LoginPage(QWidget):
        def __init__(self):
            super().__init__()
            uic.loadUi("ui/login_page.ui", self)   # builds the page
            self.loginButton.clicked.connect(self.login)

Every widget has a name you can use in code, for example
`usernameInput`, `passwordInput`, `loginButton`, `tableApplications`.
Open the .ui file in Designer (Object Inspector) to see all names.
