import getpass
import psycopg2


# ======================================================
# CONNECTION
# ======================================================

# Change dbname / user / host / port if yours are different.

conn = psycopg2.connect(
    host="localhost",
    dbname="postgres",
    user="postgres",
    password=getpass.getpass("PostgreSQL password: "),
    port=5432,
)
cur = conn.cursor()


# ======================================================
# CREATE TABLES
# ======================================================

# Remove old tables (if any) so the script can be re-run.

cur.execute("DROP TABLE IF EXISTS departments;")
cur.execute("DROP TABLE IF EXISTS employees;")


# employees table

cur.execute("""
    CREATE TABLE employees (
        emp_id     INTEGER PRIMARY KEY,
        first_name VARCHAR(50),
        last_name  VARCHAR(50),
        salary     INTEGER,
        job_title  VARCHAR(100),
        gender     VARCHAR(10),
        hire_date  DATE
    );
""")


# departments table

# No foreign key: emp_id 49823 and 71119 are not in employees.

cur.execute("""
    CREATE TABLE departments (
        emp_id    INTEGER,
        dept_name VARCHAR(50),
        dept_id   INTEGER
    );
""")


# ======================================================
# INSERT DATA
# ======================================================

employees = [
    (17679, "Robert", "Gilmore",  110000, "Operations Director",   "Male",   "2018-09-04"),
    (26650, "Elvis",  "Ritter",    86000, "Sales Manager",         "Male",   "2017-11-24"),
    (30840, "David",  "Barrow",    85000, "Data Scientist",        "Male",   "2019-12-02"),
    (49714, "Hugo",   "Forester",  55000, "IT Support Specialist", "Male",   "2019-11-22"),
    (51821, "Linda",  "Foster",    95000, "Data Scientist",        "Female", "2019-04-29"),
    (67323, "Lisa",   "Wiener",    75000, "Business Analyst",      "Female", "2018-08-09"),
    (70950, "Rodney", "Weaver",    87000, "Project Manager",       "Male",   "2018-12-20"),
    (71329, "Gayle",  "Meyer",     77000, "HR Manager",            "Female", "2019-06-28"),
    (76589, "Jason",  "Christian", 99000, "Project Manager",       "Male",   "2019-01-21"),
    (97927, "Billie", "Lanning",   67000, "Web Developer",         "Female", "2018-06-25"),
]


departments = [
    (17679, "Operations",     13),
    (26650, "Marketing",      14),
    (30840, "Operations",     13),
    (49823, "Technology",     12),
    (51821, "Operations",     13),
    (67323, "Marketing",      14),
    (71119, "Administrative", 11),
    (76589, "Operations",     13),
    (97927, "Technology",     12),
]


cur.executemany(
    "INSERT INTO employees VALUES (%s, %s, %s, %s, %s, %s, %s);", employees
)


cur.executemany(
    "INSERT INTO departments VALUES (%s, %s, %s);", departments
)

conn.commit()


# ======================================================
# QUERIES
# ======================================================



# 1. Find the employees who get paid more than Rodney Weaver.

cur.execute("""
    SELECT emp_id, first_name, last_name, salary
    FROM employees
    WHERE salary > (SELECT salary
                    FROM employees
                    WHERE first_name = 'Rodney'
                    AND last_name = 'Weaver');
""")
rows = cur.fetchall()




# 2. Find the average, min and max salaries

cur.execute("""
    SELECT AVG(salary) AS avg_salary,
           MIN(salary) AS min_salary,
           MAX(salary) AS max_salary
    FROM employees;
""")
rows = cur.fetchall()




# 3. Find the employees whose salary is more than 8700 (first name, last name, salary).

cur.execute("""
    SELECT first_name, last_name, salary
    FROM employees
    WHERE salary > 8700;
""")
rows = cur.fetchall()



# 4. Find the employees (first name, last name) who work under the Operations department.

cur.execute("""
    SELECT first_name, last_name
    FROM employees
    INNER JOIN departments
    ON employees.emp_id = departments.emp_id
    WHERE dept_name = 'Operations';
""")
rows = cur.fetchall()




# 5. Find the employees (first name, last name) who work under the Technology department.

cur.execute("""
    SELECT first_name, last_name
    FROM employees
    INNER JOIN departments
    ON employees.emp_id = departments.emp_id
    WHERE dept_name = 'Technology';
""")
rows = cur.fetchall()



# 6. Find the average salary of female employees.

cur.execute("""
    SELECT AVG(salary) AS average_salary_f
    FROM employees
    WHERE gender = 'Female';
""")
rows = cur.fetchall()




# 7. Find the average salaries of each department.


cur.execute("""
    SELECT dept_name, ROUND(AVG(salary), 2) AS average_salary
    FROM employees
    INNER JOIN departments
    ON employees.emp_id = departments.emp_id
    GROUP BY dept_name;
""")
rows = cur.fetchall()




# 8. Find the oldest and newest employees.


cur.execute("""
    (SELECT first_name, last_name, hire_date
     FROM employees
     ORDER BY hire_date ASC
     LIMIT 1)
    UNION ALL
    (SELECT first_name, last_name, hire_date
     FROM employees
     ORDER BY hire_date DESC
     LIMIT 1);
""")
rows = cur.fetchall()




# 9. Find the hiring date and department of the highest paid employee


cur.execute("""
    SELECT first_name, last_name, hire_date, dept_name, salary
    FROM employees
    LEFT JOIN departments
    ON employees.emp_id = departments.emp_id
    ORDER BY salary DESC
    LIMIT 1;
""")
rows = cur.fetchall()



# 10. Find the hiring date and department of the lowest paid employee


cur.execute("""
    SELECT first_name, last_name, hire_date, dept_name, salary
    FROM employees
    LEFT JOIN departments
    ON employees.emp_id = departments.emp_id
    ORDER BY salary ASC
    LIMIT 1;
""")
rows = cur.fetchall()



# ======================================================
# CLOSE
# ======================================================


cur.close()
conn.close()
