# Create an empty list for the movies
movies = []

# Ask the user for 3 favorite movies
for i in range(3):
    movie = input(f"Enter your favorite movie {i + 1}: ")

    # Add the movie to the list
    movies.append(movie)

# Print the full list
print("Your full list:", movies)

# Print the first movie
print("Your first movie:", movies[0])

# Print the last movie
print("Your last movie:", movies[-1])

# Print the number of movies
print("Number of movies:", len(movies))


#version 2


movie_one = input("Enter your first movie: ")
movie_two = input("Enter your second movie: ")
movie_three = input("Enter your third movie: ")
movies = []
movies.append(movie_one)
movies.append(movie_two)
movies.append(movie_three)
print("Your full list:",movies)
print("Your first movie:" ,movies[0])
print("Your last movie:" ,[-1])
print("Number of movies",len(movies))