# Ask the user for their age
user_age = int(input("Enter your age: "))
# Check if the user is under 18
if user_age < 18:
    print("You are not an adult.")
else:
    print("You are an adult")


# Ask the user for their birth year
birth_year = int(input("Enter your birth year: "))

# Calculate the age using 2025
calculate = 2025 - birth_year
print(" Your age is: ", calculate)