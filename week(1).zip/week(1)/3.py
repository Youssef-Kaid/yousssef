
#Ask the user for a sentence.
sentence = input("Enter a sentence:") 


#Character count (excluding spaces)
non_space = sentence.replace(" ","")
character_count = len(non_space)
print("Character count:",character_count)


#Counting the words
word_count = sentence.split(" ")
print("Word count:",len(word_count))

# finding the Unique words
total_words = sentence.split(" ")
unique_words = set(total_words)
print("Unique words:", unique_words)

#looking for special words
sentence = input("Enter a sentence: ")
sentence = sentence.split()
for word in sentence:
    if sentence.count(word) > 1:
        print(word)


#Looking for longest word
longest_word = sentence.split(" ")
for i in longest_word:
     if i == max(longest_word,key=len):
      print("Longest word:", i)



# Ask the user for a sentence
sentence = input("Enter a sentence: ")

# Count characters excluding spaces
character_count = len(sentence.replace(" ", ""))

# Split the sentence into words
words = sentence.split()

# Count the words
word_count = len(words)

# Find unique words
unique_words = set(words)

# Find the longest word
longest_word = ""

for word in words:
    if len(word) > len(longest_word):
        longest_word = word

# Print the results
print("Character count:", character_count)
print("Word count:", word_count)
print("Unique words:", unique_words)
print("Longest word:", longest_word)