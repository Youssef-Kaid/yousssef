

list_of_products = []

mini_market = {"apple": 3, 
               "banana": 5, 
               "bread": 2, 
               "milk": 4
               }

for i in range(3):
    products = input(f"Enter product {i + 1}:")
    products = products.casefold()



while True:
    if products not in mini_market:
        print(f"warning {products} is not available in the mini market.")
    else:
        print(f"{products} is available in the mini market.")
        list_of_products.append(products)

print("Your basket:", list_of_products) 



total_price = 0
for product in list_of_products:
    total_price += mini_market.value()


print("Total price:", )
