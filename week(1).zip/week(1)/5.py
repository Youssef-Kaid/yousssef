students = {}

# Ask for at least 3 students
number_of_students = int(input("How many students do you want to enter? "))

while number_of_students < 3:
    print("Please enter at least 3 students.")
    number_of_students = int(input("How many students do you want to enter?? "))

# Enter each student's name and 3 grades
for i in range(3):
    name = input(f"Enter a name for student {i + 1}:")

    grades = []

    for n in range(3):
        grade = float(input(f"Enter grade {n + 1} for {name}: "))
        grades.append(grade)

    students[name] = grades


# Print each student's average
print("\nStudent averages:")

highest_average = 0
highest_student = ""

for name, grades in students.items(): # if only name = key without itmes
    average = sum(grades) / len(grades) #sum(students[name]) / 3

    print(f"{name}: {average:.2f}")

    # Find the student with the highest average
    if average > highest_average:
        highest_average = average
        highest_student = name


# Extra: show student with highest average
print("\nHighest average:")
print(f"{highest_student} with {highest_average:.2f}")


